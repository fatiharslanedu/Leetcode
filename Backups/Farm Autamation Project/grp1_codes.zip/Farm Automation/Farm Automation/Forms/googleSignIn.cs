﻿using Farm_Automation.Classes;
using RegisterForm;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Farm_Automation.Forms
{
    public partial class googleSignIn : Form
    {
        SqlConnection con = new SqlConnection();
        DataAccess dao;
        public googleSignIn()
        {
            InitializeComponent();
            dao = new DataAccess();
        }

        private void btnSignIn_Click(object sender, EventArgs e)
        {
            try
            {
                LoginStatus loginStatus = dao.CheckLogin(txtBoxEmail.Text, txtBoxPassword.Text);
                if (loginStatus == LoginStatus.OK)
                {
                    MessageBox.Show("Your're logged");
                    Form_Dashboard form_Dashboard = new Form_Dashboard();

                    form_Dashboard.ShowDialog();
                    this.Dispose();
                }
                else
                {
                    MessageBox.Show("Login failed");
                }

            }
            catch (Exception)
            {
                con.Close();
            }
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }
        Point lastPoint;
        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void BtnExit_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void googleSignIn_Load(object sender, EventArgs e)
        {

        }
    }
}
