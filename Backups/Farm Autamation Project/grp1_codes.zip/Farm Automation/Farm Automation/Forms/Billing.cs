﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Farm_Automation.Forms
{
    public partial class Billing : MetroFramework.Forms.MetroForm
    {
        public Billing()
        {
            InitializeComponent();
        }

        private void Billing_Load(object sender, EventArgs e)
        {
            label8.Text = DateTime.Now.ToLongTimeString();
            getlockedtxt();
        }
        private void getlockedtxt()
        {
            txtAmount.ReadOnly = true;
            txtBillID.ReadOnly = true;
          
            txtPrice.ReadOnly = true;
            txtProductId.ReadOnly = true;
            txtProductname.ReadOnly = true;
            txtUserId.ReadOnly = true;

        }
        private void truncate()
        {
            using (SqlConnection cnn = new SqlConnection(@"Data Source=DESKTOP-6K2RTP8;Initial Catalog=ProjeVeri;Integrated Security=True"))
            using (SqlCommand cmd = new SqlCommand("TRUNCATE TABLE tempSells", cnn))
            {
                cnn.Open();
                cmd.ExecuteNonQuery();
            }
        }
        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void btnFinish_Click(object sender, EventArgs e)
        {
            truncate();
        }
    }
}
