﻿using Farm_Automation.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Farm_Automation.Forms
{
    public partial class VerifyTokenForm : Form
    {
        public string Email { get; set; }
        public string Pw { get; set; }
        public string nameSurname { get; set; }
        public string ssn { get; set; }
        public string telNo { get; set; }
        public string username { get; set; }
        public VerifyTokenForm()
        {
            InitializeComponent();
        }

        private void VerifyTokenForm_Load(object sender, EventArgs e)
        {
           
        }

        private void buttonOK_Click(object sender, EventArgs e)
        {
            if (new DataAccess().VerifyCode(Email, Pw, textBoxCode.Text))
            {
                DialogResult = DialogResult.OK;
            }
            Form1 form1 = new Form1();
            this.Dispose();
            form1.ShowDialog();

        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }
        Point lastPoint;
        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }
    }
}
