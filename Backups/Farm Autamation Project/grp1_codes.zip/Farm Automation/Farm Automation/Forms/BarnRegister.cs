﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Farm_Automation.Forms
{
    public partial class BarnRegister : MetroFramework.Forms.MetroForm
    {
        public BarnRegister()
        {
            InitializeComponent();
        }
        private SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-6K2RTP8;Initial Catalog=ProjeVeri;Integrated Security=True");
        public int id;
        private void BarnRegister_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'projeDataSet2.barn' table. You can move, or remove it, as needed.
            this.barnTableAdapter.Fill(this.projeDataSet2.barn);
            getBarnRecord();
        }
        private bool isValid()
        {
            if (txtBarnId.Text == string.Empty)
            {
                MessageBox.Show("Please enter fields with correct paramaters.", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }
        private void getBarnRecord()
        {
            SqlCommand cmd = new SqlCommand("Select * from Barn", con);
            DataTable dt = new DataTable();

            con.Open();

            SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();
            dataGridBarnRegister.DataSource = dt;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (isValid())
                {
                    SqlCommand cmd = new SqlCommand("INSERT INTO Barn VALUES (@barn_id, @barn_name, @personnel_id)", con);
                    cmd.CommandType = CommandType.Text;
                    int barn_id = int.Parse(txtBarnId.Text);
                    cmd.Parameters.AddWithValue("@barn_id", barn_id);
                    cmd.Parameters.AddWithValue("@barn_name", txtBarnName.Text);
                    int personnel_id = int.Parse(txtPersonnelId.Text);
                    cmd.Parameters.AddWithValue("@personnel_id", personnel_id);
                    

                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("New Item is Adding", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    getBarnRecord();
                    refresh();

                }
                else
                {
                    MessageBox.Show("Please Select one of Them", "Save", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Incorrect enter");
            }
        }

        private void refresh()
        {
            txtBarnId.Clear();
            txtBarnName.Clear();
            txtPersonnelId.Clear();
            txtBarnId.Focus();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("UPDATE Barn SET barn_id = @barn_id, barn_name = @barn_name, personnel_id = @personnel_id WHERE barn_id = @barn_id", con);
                cmd.CommandType = CommandType.Text;
                int barn_id = int.Parse(txtBarnId.Text);
                cmd.Parameters.AddWithValue("@barn_id", barn_id);
                cmd.Parameters.AddWithValue("@barn_name", txtBarnName.Text);
                int personnel_id = int.Parse(txtPersonnelId.Text);
                cmd.Parameters.AddWithValue("@personnel_id", personnel_id);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("New Item is Adding", "Updated", MessageBoxButtons.OK, MessageBoxIcon.Information);
                getBarnRecord();
                refresh();
            }
            catch
            {
                MessageBox.Show("Please Select one of Them", "Update", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("DELETE FROM Barn WHERE barn_id = @barn_id", con);
                cmd.CommandType = CommandType.Text;

                cmd.Parameters.AddWithValue("@barn_id", txtBarnId.Text);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Barn is Deleted", "Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);
                getBarnRecord();
                refresh();
            }
            catch(Exception)
            {

            }
        }

        private void dataGridBarnRegister_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {

                txtBarnId.Text = dataGridBarnRegister.SelectedRows[0].Cells[0].Value.ToString();
                txtBarnName.Text = dataGridBarnRegister.SelectedRows[0].Cells[1].Value.ToString();
                txtPersonnelId.Text = dataGridBarnRegister.SelectedRows[0].Cells[2].Value.ToString();
                
            }
            catch
            {
                MessageBox.Show("Please Select one of Them", "Update", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            refresh();
        }
    }
}
