﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Farm_Automation.Forms
{
    public partial class productRegister : MetroFramework.Forms.MetroForm
    {
        public productRegister()
        {
            InitializeComponent();
        }
        private SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-6K2RTP8;Initial Catalog=ProjeVeri;Integrated Security=True");
        public int id;
        private void productRegister_Load(object sender, EventArgs e)
        {
            getStaffRecord();
        }
        private bool isValid()
        {
            if (txtProId.Text == string.Empty)
            {
                MessageBox.Show("Please enter fields with correct paramaters.", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }
        private void getStaffRecord()
        {
            SqlCommand cmd = new SqlCommand("Select * from PropProduct", con);
            DataTable dt = new DataTable();

            con.Open();

            SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();
            dataGridProduct.DataSource = dt;
        }
        private void refresh()
        {
            txtAmount.Clear();
            txtCalories.Clear();
            txtCarbon.Clear();
            txtCholestorel.Clear();
            txtExpire.Clear();
            txtPrice.Clear();
            txtProducDate.Clear();
            txtProductName.Clear();
            txtProId.Clear();
            txtProte.Clear();
            txtTotalFat.Clear();
            txtVitami.Clear();
            txtWareId.Clear();
            txtWater.Clear();
            txtProId.Focus();
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            //try
            //{
                if (isValid())
                {
                    SqlCommand cmd = new SqlCommand("INSERT INTO PropProduct VALUES (@pro_id, @ware_id, @pro_name, @water, @calories, @total_fat, @cholestorel, @carbohydrate, @protein, @vitamin_A, @amount, @productionDate, @ExpirationDate, @price)", con);
                    cmd.CommandType = CommandType.Text;
                    int pro_id = int.Parse(txtProId.Text);
                    cmd.Parameters.AddWithValue("@pro_id", pro_id);
                    int ware_id = int.Parse(txtWareId.Text);
                    cmd.Parameters.AddWithValue("@ware_id", ware_id);
                    cmd.Parameters.AddWithValue("@pro_name", txtProductName.Text);
                    decimal water = decimal.Parse(txtWater.Text);
                    cmd.Parameters.AddWithValue("@water", water);
                    decimal calories = decimal.Parse(txtCalories.Text);
                    cmd.Parameters.AddWithValue("@calories", calories);
                    decimal total_fat = decimal.Parse(txtTotalFat.Text);
                    cmd.Parameters.AddWithValue("@total_fat", total_fat);
                    decimal cholestorel = decimal.Parse(txtCholestorel.Text);
                    cmd.Parameters.AddWithValue("@cholestorel", cholestorel);
                    decimal carbohydrate = decimal.Parse(txtCarbon.Text);
                    cmd.Parameters.AddWithValue("@carbohydrate", carbohydrate);
                    decimal protein = decimal.Parse(txtProte.Text);
                    cmd.Parameters.AddWithValue("@protein", protein);
                    decimal vitamin_A = decimal.Parse(txtVitami.Text);
                    cmd.Parameters.AddWithValue("@vitamin_A", vitamin_A);
                    decimal amount = decimal.Parse(txtAmount.Text);
                    cmd.Parameters.AddWithValue("@amount", amount);
                    cmd.Parameters.AddWithValue("@productionDate", txtProducDate.Text);
                    cmd.Parameters.AddWithValue("@ExpirationDate", txtExpire.Text);
                    decimal price = decimal.Parse(txtPrice.Text);
                    cmd.Parameters.AddWithValue("@price", price);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("New Item is Adding", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    getStaffRecord();
                    refresh();

                }
                else
                {
                    MessageBox.Show("Please Select one of Them", "Save", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            //}
            //catch (Exception)
            //{
            //    MessageBox.Show("Incorrect enter");
            //}
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (isValid())
                {
                    SqlCommand cmd = new SqlCommand("UPDATE PropProduct SET pro_id = @pro_id, ware_id = @ware_id, pro_name = @pro_name, water= @water, calories = @calories, total_fat = @total_fat, cholestorel = @cholestorel, carbohydrate = @carbohydrate, protein = @protein, vitamin_A = @vitamin_A, amount = @amount, productionDate = @productionDate, ExpirationDate = @ExpirationDate, price = @price WHERE pro_id = @pro_id", con);
                    cmd.CommandType = CommandType.Text;
                    int pro_id = int.Parse(txtProId.Text);
                    cmd.Parameters.AddWithValue("@pro_id", pro_id);
                    int ware_id = int.Parse(txtWareId.Text);
                    cmd.Parameters.AddWithValue("@ware_id", ware_id);
                    cmd.Parameters.AddWithValue("@pro_name", txtProductName.Text);
                    decimal water = decimal.Parse(txtWater.Text);
                    cmd.Parameters.AddWithValue("@water", water);
                    decimal calories = decimal.Parse(txtCalories.Text);
                    cmd.Parameters.AddWithValue("@calories", calories);
                    decimal total_fat = decimal.Parse(txtTotalFat.Text);
                    cmd.Parameters.AddWithValue("@total_fat", total_fat);
                    decimal cholestorel = decimal.Parse(txtCholestorel.Text);
                    cmd.Parameters.AddWithValue("@cholestorel", cholestorel);
                    decimal carbohydrate = decimal.Parse(txtCarbon.Text);
                    cmd.Parameters.AddWithValue("@carbohydrate", carbohydrate);
                    decimal protein = decimal.Parse(txtProte.Text);
                    cmd.Parameters.AddWithValue("@protein", protein);
                    decimal vitamin_A = decimal.Parse(txtVitami.Text);
                    cmd.Parameters.AddWithValue("@vitamin_A", vitamin_A);
                    decimal amount = decimal.Parse(txtAmount.Text);
                    cmd.Parameters.AddWithValue("@amount", amount);
                    cmd.Parameters.AddWithValue("@productionDate", txtProducDate.Text);
                    cmd.Parameters.AddWithValue("@ExpirationDate", txtExpire.Text);
                    decimal price = decimal.Parse(txtPrice.Text);
                    cmd.Parameters.AddWithValue("@price", price);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("New Item is Updated", "Updated", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    getStaffRecord();
                    refresh();

                }
                else
                {
                    MessageBox.Show("Please Select one of Them", "Save", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Incorrect enter");
            }
        }

        private void dataGridProduct_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {

                txtProId.Text = dataGridProduct.SelectedRows[0].Cells[0].Value.ToString();
                txtWareId.Text = dataGridProduct.SelectedRows[0].Cells[1].Value.ToString();
                txtProductName.Text = dataGridProduct.SelectedRows[0].Cells[2].Value.ToString();
                txtWater.Text = dataGridProduct.SelectedRows[0].Cells[3].Value.ToString();
                txtCalories.Text = dataGridProduct.SelectedRows[0].Cells[4].Value.ToString();
                txtTotalFat.Text = dataGridProduct.SelectedRows[0].Cells[5].Value.ToString();
                txtCholestorel.Text = dataGridProduct.SelectedRows[0].Cells[6].Value.ToString();
                txtCarbon.Text = dataGridProduct.SelectedRows[0].Cells[7].Value.ToString();
                txtProte.Text = dataGridProduct.SelectedRows[0].Cells[8].Value.ToString();
                txtVitami.Text = dataGridProduct.SelectedRows[0].Cells[9].Value.ToString();
                txtAmount.Text = dataGridProduct.SelectedRows[0].Cells[10].Value.ToString();
                txtProducDate.Text = dataGridProduct.SelectedRows[0].Cells[11].Value.ToString();
                txtExpire.Text = dataGridProduct.SelectedRows[0].Cells[12].Value.ToString();
                txtPrice.Text = dataGridProduct.SelectedRows[0].Cells[13].Value.ToString();
            }
            catch
            {
                MessageBox.Show("Please Select one of Them", "Update", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("DELETE FROM PropProduct WHERE pro_id = @pro_id", con);
            cmd.CommandType = CommandType.Text;

            cmd.Parameters.AddWithValue("@pro_id", txtProId.Text);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Product is Deleted", "Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);
            getStaffRecord();
            refresh();
        }
    }
}
