﻿
namespace Farm_Automation.Forms
{
    partial class PoultryRegister
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.metroSetControlBox1 = new MetroSet_UI.Controls.MetroSetControlBox();
            this.metroSetControlBox2 = new MetroSet_UI.Controls.MetroSetControlBox();
            this.txtBreed = new System.Windows.Forms.TextBox();
            this.dataGridPoultryRegister = new System.Windows.Forms.DataGridView();
            this.txtAmountofMeat = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtWeight = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtCoopId = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtAnimalType = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtBirdId = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.projeVeriDataSet5 = new Farm_Automation.ProjeVeriDataSet5();
            this.propsPoultryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.props_PoultryTableAdapter = new Farm_Automation.ProjeVeriDataSet5TableAdapters.Props_PoultryTableAdapter();
            this.birdidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.animaltypeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.coopidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.breedDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.weightDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.amountOfmeatDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridPoultryRegister)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.projeVeriDataSet5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.propsPoultryBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // metroSetControlBox1
            // 
            this.metroSetControlBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.metroSetControlBox1.CloseHoverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(183)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.metroSetControlBox1.CloseHoverForeColor = System.Drawing.Color.White;
            this.metroSetControlBox1.CloseNormalForeColor = System.Drawing.Color.Gray;
            this.metroSetControlBox1.DisabledForeColor = System.Drawing.Color.DimGray;
            this.metroSetControlBox1.IsDerivedStyle = true;
            this.metroSetControlBox1.Location = new System.Drawing.Point(924, 4);
            this.metroSetControlBox1.MaximizeBox = true;
            this.metroSetControlBox1.MaximizeHoverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.metroSetControlBox1.MaximizeHoverForeColor = System.Drawing.Color.Gray;
            this.metroSetControlBox1.MaximizeNormalForeColor = System.Drawing.Color.Gray;
            this.metroSetControlBox1.MinimizeBox = true;
            this.metroSetControlBox1.MinimizeHoverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.metroSetControlBox1.MinimizeHoverForeColor = System.Drawing.Color.Gray;
            this.metroSetControlBox1.MinimizeNormalForeColor = System.Drawing.Color.Gray;
            this.metroSetControlBox1.Name = "metroSetControlBox1";
            this.metroSetControlBox1.Size = new System.Drawing.Size(100, 25);
            this.metroSetControlBox1.Style = MetroSet_UI.Enums.Style.Light;
            this.metroSetControlBox1.StyleManager = null;
            this.metroSetControlBox1.TabIndex = 0;
            this.metroSetControlBox1.Text = "metroSetControlBox1";
            this.metroSetControlBox1.ThemeAuthor = "Narwin";
            this.metroSetControlBox1.ThemeName = "MetroLite";
            // 
            // metroSetControlBox2
            // 
            this.metroSetControlBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.metroSetControlBox2.CloseHoverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(183)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.metroSetControlBox2.CloseHoverForeColor = System.Drawing.Color.White;
            this.metroSetControlBox2.CloseNormalForeColor = System.Drawing.Color.Gray;
            this.metroSetControlBox2.DisabledForeColor = System.Drawing.Color.DimGray;
            this.metroSetControlBox2.IsDerivedStyle = true;
            this.metroSetControlBox2.Location = new System.Drawing.Point(925, 4);
            this.metroSetControlBox2.MaximizeBox = true;
            this.metroSetControlBox2.MaximizeHoverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.metroSetControlBox2.MaximizeHoverForeColor = System.Drawing.Color.Gray;
            this.metroSetControlBox2.MaximizeNormalForeColor = System.Drawing.Color.Gray;
            this.metroSetControlBox2.MinimizeBox = true;
            this.metroSetControlBox2.MinimizeHoverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.metroSetControlBox2.MinimizeHoverForeColor = System.Drawing.Color.Gray;
            this.metroSetControlBox2.MinimizeNormalForeColor = System.Drawing.Color.Gray;
            this.metroSetControlBox2.Name = "metroSetControlBox2";
            this.metroSetControlBox2.Size = new System.Drawing.Size(100, 25);
            this.metroSetControlBox2.Style = MetroSet_UI.Enums.Style.Light;
            this.metroSetControlBox2.StyleManager = null;
            this.metroSetControlBox2.TabIndex = 1;
            this.metroSetControlBox2.Text = "metroSetControlBox2";
            this.metroSetControlBox2.ThemeAuthor = "Narwin";
            this.metroSetControlBox2.ThemeName = "MetroLite";
            // 
            // txtBreed
            // 
            this.txtBreed.Location = new System.Drawing.Point(264, 204);
            this.txtBreed.Name = "txtBreed";
            this.txtBreed.Size = new System.Drawing.Size(224, 26);
            this.txtBreed.TabIndex = 116;
            // 
            // dataGridPoultryRegister
            // 
            this.dataGridPoultryRegister.AutoGenerateColumns = false;
            this.dataGridPoultryRegister.BackgroundColor = System.Drawing.Color.LightSeaGreen;
            this.dataGridPoultryRegister.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridPoultryRegister.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.birdidDataGridViewTextBoxColumn,
            this.animaltypeDataGridViewTextBoxColumn,
            this.coopidDataGridViewTextBoxColumn,
            this.breedDataGridViewTextBoxColumn,
            this.priceDataGridViewTextBoxColumn,
            this.weightDataGridViewTextBoxColumn,
            this.amountOfmeatDataGridViewTextBoxColumn});
            this.dataGridPoultryRegister.DataSource = this.propsPoultryBindingSource;
            this.dataGridPoultryRegister.Location = new System.Drawing.Point(43, 299);
            this.dataGridPoultryRegister.Name = "dataGridPoultryRegister";
            this.dataGridPoultryRegister.Size = new System.Drawing.Size(939, 321);
            this.dataGridPoultryRegister.TabIndex = 114;
            this.dataGridPoultryRegister.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridPoultryRegister_CellClick);
            // 
            // txtAmountofMeat
            // 
            this.txtAmountofMeat.Location = new System.Drawing.Point(657, 170);
            this.txtAmountofMeat.Name = "txtAmountofMeat";
            this.txtAmountofMeat.Size = new System.Drawing.Size(224, 26);
            this.txtAmountofMeat.TabIndex = 111;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(509, 170);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(140, 22);
            this.label7.TabIndex = 110;
            this.label7.Text = "Amount of Meat:";
            // 
            // txtWeight
            // 
            this.txtWeight.Location = new System.Drawing.Point(657, 133);
            this.txtWeight.Name = "txtWeight";
            this.txtWeight.Size = new System.Drawing.Size(224, 26);
            this.txtWeight.TabIndex = 109;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(578, 133);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(71, 22);
            this.label8.TabIndex = 108;
            this.label8.Text = "Weight:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(191, 208);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 22);
            this.label3.TabIndex = 104;
            this.label3.Text = "Breed:";
            // 
            // txtCoopId
            // 
            this.txtCoopId.Location = new System.Drawing.Point(264, 172);
            this.txtCoopId.Name = "txtCoopId";
            this.txtCoopId.Size = new System.Drawing.Size(224, 26);
            this.txtCoopId.TabIndex = 103;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(174, 173);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 22);
            this.label4.TabIndex = 102;
            this.label4.Text = "Coop ID:";
            // 
            // txtAnimalType
            // 
            this.txtAnimalType.Location = new System.Drawing.Point(264, 136);
            this.txtAnimalType.Name = "txtAnimalType";
            this.txtAnimalType.Size = new System.Drawing.Size(224, 26);
            this.txtAnimalType.TabIndex = 101;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(143, 137);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(115, 22);
            this.label2.TabIndex = 100;
            this.label2.Text = "Animal Type:";
            // 
            // txtBirdId
            // 
            this.txtBirdId.Location = new System.Drawing.Point(264, 100);
            this.txtBirdId.Name = "txtBirdId";
            this.txtBirdId.Size = new System.Drawing.Size(224, 26);
            this.txtBirdId.TabIndex = 99;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(185, 100);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 22);
            this.label1.TabIndex = 98;
            this.label1.Text = "Bird ID:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(591, 97);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(56, 22);
            this.label6.TabIndex = 105;
            this.label6.Text = "Price:";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // txtPrice
            // 
            this.txtPrice.Location = new System.Drawing.Point(657, 96);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Size = new System.Drawing.Size(224, 26);
            this.txtPrice.TabIndex = 106;
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.Red;
            this.btnDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnDelete.Location = new System.Drawing.Point(515, 641);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(125, 43);
            this.btnDelete.TabIndex = 120;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnRefresh
            // 
            this.btnRefresh.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnRefresh.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefresh.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnRefresh.Location = new System.Drawing.Point(646, 641);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(125, 43);
            this.btnRefresh.TabIndex = 119;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.UseVisualStyleBackColor = false;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.BackColor = System.Drawing.Color.Green;
            this.btnUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdate.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnUpdate.Location = new System.Drawing.Point(384, 641);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(125, 43);
            this.btnUpdate.TabIndex = 118;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = false;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnSave.Location = new System.Drawing.Point(253, 641);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(125, 43);
            this.btnSave.TabIndex = 117;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // projeVeriDataSet5
            // 
            this.projeVeriDataSet5.DataSetName = "ProjeVeriDataSet5";
            this.projeVeriDataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // propsPoultryBindingSource
            // 
            this.propsPoultryBindingSource.DataMember = "Props_Poultry";
            this.propsPoultryBindingSource.DataSource = this.projeVeriDataSet5;
            // 
            // props_PoultryTableAdapter
            // 
            this.props_PoultryTableAdapter.ClearBeforeFill = true;
            // 
            // birdidDataGridViewTextBoxColumn
            // 
            this.birdidDataGridViewTextBoxColumn.DataPropertyName = "bird_id";
            this.birdidDataGridViewTextBoxColumn.HeaderText = "bird_id";
            this.birdidDataGridViewTextBoxColumn.Name = "birdidDataGridViewTextBoxColumn";
            this.birdidDataGridViewTextBoxColumn.Width = 110;
            // 
            // animaltypeDataGridViewTextBoxColumn
            // 
            this.animaltypeDataGridViewTextBoxColumn.DataPropertyName = "animal_type";
            this.animaltypeDataGridViewTextBoxColumn.HeaderText = "animal_type";
            this.animaltypeDataGridViewTextBoxColumn.Name = "animaltypeDataGridViewTextBoxColumn";
            this.animaltypeDataGridViewTextBoxColumn.Width = 130;
            // 
            // coopidDataGridViewTextBoxColumn
            // 
            this.coopidDataGridViewTextBoxColumn.DataPropertyName = "coop_id";
            this.coopidDataGridViewTextBoxColumn.HeaderText = "coop_id";
            this.coopidDataGridViewTextBoxColumn.Name = "coopidDataGridViewTextBoxColumn";
            this.coopidDataGridViewTextBoxColumn.Width = 130;
            // 
            // breedDataGridViewTextBoxColumn
            // 
            this.breedDataGridViewTextBoxColumn.DataPropertyName = "breed";
            this.breedDataGridViewTextBoxColumn.HeaderText = "breed";
            this.breedDataGridViewTextBoxColumn.Name = "breedDataGridViewTextBoxColumn";
            this.breedDataGridViewTextBoxColumn.Width = 120;
            // 
            // priceDataGridViewTextBoxColumn
            // 
            this.priceDataGridViewTextBoxColumn.DataPropertyName = "price";
            this.priceDataGridViewTextBoxColumn.HeaderText = "price";
            this.priceDataGridViewTextBoxColumn.Name = "priceDataGridViewTextBoxColumn";
            this.priceDataGridViewTextBoxColumn.Width = 110;
            // 
            // weightDataGridViewTextBoxColumn
            // 
            this.weightDataGridViewTextBoxColumn.DataPropertyName = "weight";
            this.weightDataGridViewTextBoxColumn.HeaderText = "weight";
            this.weightDataGridViewTextBoxColumn.Name = "weightDataGridViewTextBoxColumn";
            this.weightDataGridViewTextBoxColumn.Width = 120;
            // 
            // amountOfmeatDataGridViewTextBoxColumn
            // 
            this.amountOfmeatDataGridViewTextBoxColumn.DataPropertyName = "amountOf_meat";
            this.amountOfmeatDataGridViewTextBoxColumn.HeaderText = "amountOf_meat";
            this.amountOfmeatDataGridViewTextBoxColumn.Name = "amountOfmeatDataGridViewTextBoxColumn";
            this.amountOfmeatDataGridViewTextBoxColumn.Width = 160;
            // 
            // PoultryRegister
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1024, 720);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.txtBreed);
            this.Controls.Add(this.dataGridPoultryRegister);
            this.Controls.Add(this.txtAmountofMeat);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtWeight);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtPrice);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtCoopId);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtAnimalType);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtBirdId);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.metroSetControlBox2);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "PoultryRegister";
            this.Text = "Poultry Register";
            this.TextAlign = MetroFramework.Forms.MetroFormTextAlign.Center;
            this.Load += new System.EventHandler(this.PoultryRegister_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridPoultryRegister)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.projeVeriDataSet5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.propsPoultryBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroSet_UI.Controls.MetroSetControlBox metroSetControlBox1;
        private MetroSet_UI.Controls.MetroSetControlBox metroSetControlBox2;
        private System.Windows.Forms.TextBox txtBreed;
        private System.Windows.Forms.DataGridView dataGridPoultryRegister;
        private System.Windows.Forms.TextBox txtAmountofMeat;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtWeight;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtCoopId;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtAnimalType;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtBirdId;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnSave;
        private ProjeVeriDataSet5 projeVeriDataSet5;
        private System.Windows.Forms.BindingSource propsPoultryBindingSource;
        private ProjeVeriDataSet5TableAdapters.Props_PoultryTableAdapter props_PoultryTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn birdidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn animaltypeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn coopidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn breedDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn weightDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn amountOfmeatDataGridViewTextBoxColumn;
    }
}