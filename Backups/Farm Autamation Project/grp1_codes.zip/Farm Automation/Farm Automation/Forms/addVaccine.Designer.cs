﻿
namespace Farm_Automation.Forms
{
    partial class addVaccine
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.dataGridAddMembers = new System.Windows.Forms.DataGridView();
            this.txtVaccineName = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtVaccineId = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.projeVeriDataSet9 = new Farm_Automation.ProjeVeriDataSet9();
            this.vaccineBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.vaccineTableAdapter = new Farm_Automation.ProjeVeriDataSet9TableAdapters.VaccineTableAdapter();
            this.vaccineidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vaccinenameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridAddMembers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.projeVeriDataSet9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vaccineBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.Red;
            this.btnDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnDelete.Location = new System.Drawing.Point(247, 445);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(103, 43);
            this.btnDelete.TabIndex = 141;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnRefresh
            // 
            this.btnRefresh.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnRefresh.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefresh.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnRefresh.Location = new System.Drawing.Point(356, 445);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(103, 43);
            this.btnRefresh.TabIndex = 140;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.UseVisualStyleBackColor = false;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.BackColor = System.Drawing.Color.Green;
            this.btnUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdate.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnUpdate.Location = new System.Drawing.Point(138, 445);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(103, 43);
            this.btnUpdate.TabIndex = 139;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = false;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnSave.Location = new System.Drawing.Point(29, 445);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(103, 43);
            this.btnSave.TabIndex = 138;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // dataGridAddMembers
            // 
            this.dataGridAddMembers.AutoGenerateColumns = false;
            this.dataGridAddMembers.BackgroundColor = System.Drawing.Color.LightSeaGreen;
            this.dataGridAddMembers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridAddMembers.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.vaccineidDataGridViewTextBoxColumn,
            this.vaccinenameDataGridViewTextBoxColumn});
            this.dataGridAddMembers.DataSource = this.vaccineBindingSource;
            this.dataGridAddMembers.Location = new System.Drawing.Point(16, 212);
            this.dataGridAddMembers.Name = "dataGridAddMembers";
            this.dataGridAddMembers.Size = new System.Drawing.Size(495, 227);
            this.dataGridAddMembers.TabIndex = 137;
            this.dataGridAddMembers.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridAddMembers_CellClick);
            // 
            // txtVaccineName
            // 
            this.txtVaccineName.Location = new System.Drawing.Point(225, 125);
            this.txtVaccineName.Name = "txtVaccineName";
            this.txtVaccineName.Size = new System.Drawing.Size(224, 26);
            this.txtVaccineName.TabIndex = 134;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(71, 126);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(131, 22);
            this.label7.TabIndex = 133;
            this.label7.Text = "Vaccine Name:";
            // 
            // txtVaccineId
            // 
            this.txtVaccineId.Location = new System.Drawing.Point(225, 93);
            this.txtVaccineId.Name = "txtVaccineId";
            this.txtVaccineId.Size = new System.Drawing.Size(224, 26);
            this.txtVaccineId.TabIndex = 132;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(101, 93);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(101, 22);
            this.label8.TabIndex = 131;
            this.label8.Text = "Vaccine ID:";
            // 
            // projeVeriDataSet9
            // 
            this.projeVeriDataSet9.DataSetName = "ProjeVeriDataSet9";
            this.projeVeriDataSet9.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // vaccineBindingSource
            // 
            this.vaccineBindingSource.DataMember = "Vaccine";
            this.vaccineBindingSource.DataSource = this.projeVeriDataSet9;
            // 
            // vaccineTableAdapter
            // 
            this.vaccineTableAdapter.ClearBeforeFill = true;
            // 
            // vaccineidDataGridViewTextBoxColumn
            // 
            this.vaccineidDataGridViewTextBoxColumn.DataPropertyName = "vaccine_id";
            this.vaccineidDataGridViewTextBoxColumn.HeaderText = "vaccine_id";
            this.vaccineidDataGridViewTextBoxColumn.Name = "vaccineidDataGridViewTextBoxColumn";
            this.vaccineidDataGridViewTextBoxColumn.Width = 200;
            // 
            // vaccinenameDataGridViewTextBoxColumn
            // 
            this.vaccinenameDataGridViewTextBoxColumn.DataPropertyName = "vaccine_name";
            this.vaccinenameDataGridViewTextBoxColumn.HeaderText = "vaccine_name";
            this.vaccinenameDataGridViewTextBoxColumn.Name = "vaccinenameDataGridViewTextBoxColumn";
            this.vaccinenameDataGridViewTextBoxColumn.Width = 250;
            // 
            // addVaccine
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(527, 544);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.dataGridAddMembers);
            this.Controls.Add(this.txtVaccineName);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtVaccineId);
            this.Controls.Add(this.label8);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "addVaccine";
            this.Text = "Vaccine ";
            this.TextAlign = MetroFramework.Forms.MetroFormTextAlign.Center;
            this.Load += new System.EventHandler(this.addVaccine_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridAddMembers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.projeVeriDataSet9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vaccineBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.DataGridView dataGridAddMembers;
        private System.Windows.Forms.TextBox txtVaccineName;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtVaccineId;
        private System.Windows.Forms.Label label8;
        private ProjeVeriDataSet9 projeVeriDataSet9;
        private System.Windows.Forms.BindingSource vaccineBindingSource;
        private ProjeVeriDataSet9TableAdapters.VaccineTableAdapter vaccineTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn vaccineidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn vaccinenameDataGridViewTextBoxColumn;
    }
}