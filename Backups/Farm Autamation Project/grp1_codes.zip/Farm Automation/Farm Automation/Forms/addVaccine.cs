﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Farm_Automation.Forms
{
    public partial class addVaccine : MetroFramework.Forms.MetroForm
    {
        public addVaccine()
        {
            InitializeComponent();
        }
        private SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-6K2RTP8;Initial Catalog=ProjeVeri;Integrated Security=True");
        public int id;
        private void addVaccine_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'projeVeriDataSet9.Vaccine' table. You can move, or remove it, as needed.
            this.vaccineTableAdapter.Fill(this.projeVeriDataSet9.Vaccine);
            getVaccineRecord();
        }
        private bool isValid()
        {
            if (txtVaccineId.Text == string.Empty)
            {
                MessageBox.Show("Please enter fields with correct paramaters.", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (isValid())
                {
                    SqlCommand cmd = new SqlCommand("INSERT INTO Vaccine VALUES (@vaccine_id, @vaccine_name)", con);
                    cmd.CommandType = CommandType.Text;
                    int vaccine_id = int.Parse(txtVaccineId.Text);
                    cmd.Parameters.AddWithValue("@vaccine_id", vaccine_id);
                    cmd.Parameters.AddWithValue("@vaccine_name", txtVaccineName.Text);
                   

                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("New Vaccine is Adding", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    getVaccineRecord();
                    refresh();

                }
                else
                {
                    MessageBox.Show("Please Select one of Them", "Save", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Incorrect enter");
            }
        }

        private void refresh()
        {
            txtVaccineId.Clear();
            txtVaccineName.Clear();
            txtVaccineId.Focus();
        }

        private void getVaccineRecord()
        {
            SqlCommand cmd = new SqlCommand("Select * from Vaccine", con);
            DataTable dt = new DataTable();

            con.Open();

            SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();
            dataGridAddMembers.DataSource = dt;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("UPDATE  Vaccine SET vaccine_id = @vaccine_id, vaccine_name = @vaccine_name WHERE vaccine_id = @vaccine_id ", con);
                cmd.CommandType = CommandType.Text;
                int vaccine_id = int.Parse(txtVaccineId.Text);
                cmd.Parameters.AddWithValue("@vaccine_id", vaccine_id);
                cmd.Parameters.AddWithValue("@vaccine_name", txtVaccineName.Text);           
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("New vaccine is Updated", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
                getVaccineRecord();
                refresh();
            }
            catch
            {
                MessageBox.Show("Incorrect enter");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {

            try
            {
                SqlCommand cmd = new SqlCommand("DELETE FROM Vaccine WHERE vaccine_id = @vaccine_id", con);
                cmd.CommandType = CommandType.Text;

                cmd.Parameters.AddWithValue("@vaccine_id", txtVaccineId.Text);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Vaccine deleted", "Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);
                getVaccineRecord();
                refresh();
            }
            catch
            {

            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            refresh();
        }

        private void dataGridAddMembers_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {

                txtVaccineId.Text = dataGridAddMembers.SelectedRows[0].Cells[0].Value.ToString();
                txtVaccineName.Text = dataGridAddMembers.SelectedRows[0].Cells[1].Value.ToString();
                
            }
            catch
            {

            }
        }
    }
}
