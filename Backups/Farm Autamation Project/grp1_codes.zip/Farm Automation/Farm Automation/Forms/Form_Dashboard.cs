﻿using Farm_Automation.UserControls;
using System;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace Farm_Automation.Forms
{
    public partial class Form_Dashboard : Form
    {
        public Form_Dashboard()
        {
            InitializeComponent();
            UC_AnaEkran ae = new UC_AnaEkran();
            AddControlsToPanel(ae);

        }
        private void AddControlsToPanel(Control c)
        {
            c.Dock = DockStyle.Fill;
            pnlControl.Controls.Clear();
            pnlControl.Controls.Add(c);
        }
        private void truncate()
        {
            using (SqlConnection cnn = new SqlConnection(@"Data Source=DESKTOP-6K2RTP8;Initial Catalog=ProjeVeri;Integrated Security=True"))
            using (SqlCommand cmd = new SqlCommand("TRUNCATE TABLE tempSells", cnn))
            {
                cnn.Open();
                cmd.ExecuteNonQuery();
            }
        }
        private void btnExit1_Click(object sender, EventArgs e)
        {
            this.Dispose();
            truncate();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Form_Dashboard_Load(object sender, EventArgs e)
        {
            timer1.Start();
            lblTarih.Text = DateTime.Now.ToLongTimeString();
            lblDate.Text = DateTime.Now.ToLongDateString();

        }

        private void lblTarih_Click(object sender, EventArgs e)
        {
            
        }

        private void lblAdSoyad_Click(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            UC_AnaEkran ae = new UC_AnaEkran();
            AddControlsToPanel(ae);
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            UC_Register register = new UC_Register();
            AddControlsToPanel(register);
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Users users = new Users();
            AddControlsToPanel(users);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            UC_ProductReview uC_Product = new UC_ProductReview();
            
                AddControlsToPanel(uC_Product);
            
        }

        private void panel5_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }
        Point lastPoint;
        private void panel5_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            UC_DataAnalys uC_DataAnalys = new UC_DataAnalys();
            AddControlsToPanel(uC_DataAnalys);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblTarih.Text = DateTime.Now.ToLongTimeString();
            timer1.Start();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            UC_Sales uC_Sales = new UC_Sales();
            AddControlsToPanel(uC_Sales);
        }

        private void btnVaccine_Click(object sender, EventArgs e)
        {

        }
    }
}
