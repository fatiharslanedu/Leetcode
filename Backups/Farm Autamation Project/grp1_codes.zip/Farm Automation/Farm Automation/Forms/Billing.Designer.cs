﻿
namespace Farm_Automation.Forms
{
    partial class Billing
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtBillID = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtUserId = new System.Windows.Forms.TextBox();
            this.label = new System.Windows.Forms.Label();
            this.txtProductId = new System.Windows.Forms.TextBox();
            this.asd = new System.Windows.Forms.Label();
            this.txtProductname = new System.Windows.Forms.TextBox();
            this.sad = new System.Windows.Forms.Label();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.sadsf = new System.Windows.Forms.Label();
            this.txtAmount = new System.Windows.Forms.TextBox();
            this.txtAmossadaunt = new System.Windows.Forms.Label();
            this.btnFinish = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(100, 155);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 21);
            this.label1.TabIndex = 0;
            this.label1.Text = "Billing ID:";
            // 
            // txtBillID
            // 
            this.txtBillID.Location = new System.Drawing.Point(104, 179);
            this.txtBillID.Name = "txtBillID";
            this.txtBillID.Size = new System.Drawing.Size(205, 27);
            this.txtBillID.TabIndex = 1;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(615, 80);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(57, 21);
            this.label8.TabIndex = 14;
            this.label8.Text = "label8";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // txtUserId
            // 
            this.txtUserId.Location = new System.Drawing.Point(104, 255);
            this.txtUserId.Name = "txtUserId";
            this.txtUserId.Size = new System.Drawing.Size(205, 27);
            this.txtUserId.TabIndex = 16;
            this.txtUserId.Text = "admin";
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.Location = new System.Drawing.Point(100, 231);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(67, 21);
            this.label.TabIndex = 15;
            this.label.Text = "User ID:";
            // 
            // txtProductId
            // 
            this.txtProductId.Location = new System.Drawing.Point(416, 179);
            this.txtProductId.Name = "txtProductId";
            this.txtProductId.Size = new System.Drawing.Size(205, 27);
            this.txtProductId.TabIndex = 20;
            // 
            // asd
            // 
            this.asd.AutoSize = true;
            this.asd.Location = new System.Drawing.Point(412, 155);
            this.asd.Name = "asd";
            this.asd.Size = new System.Drawing.Size(97, 21);
            this.asd.TabIndex = 19;
            this.asd.Text = "Product ID:";
            // 
            // txtProductname
            // 
            this.txtProductname.Location = new System.Drawing.Point(416, 255);
            this.txtProductname.Name = "txtProductname";
            this.txtProductname.Size = new System.Drawing.Size(205, 27);
            this.txtProductname.TabIndex = 22;
            // 
            // sad
            // 
            this.sad.AutoSize = true;
            this.sad.Location = new System.Drawing.Point(412, 231);
            this.sad.Name = "sad";
            this.sad.Size = new System.Drawing.Size(128, 21);
            this.sad.TabIndex = 21;
            this.sad.Text = "Product Name:";
            // 
            // txtPrice
            // 
            this.txtPrice.Location = new System.Drawing.Point(416, 331);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Size = new System.Drawing.Size(205, 27);
            this.txtPrice.TabIndex = 24;
            // 
            // sadsf
            // 
            this.sadsf.AutoSize = true;
            this.sadsf.Location = new System.Drawing.Point(412, 307);
            this.sadsf.Name = "sadsf";
            this.sadsf.Size = new System.Drawing.Size(51, 21);
            this.sadsf.TabIndex = 23;
            this.sadsf.Text = "Price:";
            // 
            // txtAmount
            // 
            this.txtAmount.Location = new System.Drawing.Point(416, 401);
            this.txtAmount.Name = "txtAmount";
            this.txtAmount.Size = new System.Drawing.Size(205, 27);
            this.txtAmount.TabIndex = 26;
            // 
            // txtAmossadaunt
            // 
            this.txtAmossadaunt.AutoSize = true;
            this.txtAmossadaunt.Location = new System.Drawing.Point(412, 377);
            this.txtAmossadaunt.Name = "txtAmossadaunt";
            this.txtAmossadaunt.Size = new System.Drawing.Size(79, 21);
            this.txtAmossadaunt.TabIndex = 25;
            this.txtAmossadaunt.Text = "Amount:";
            // 
            // btnFinish
            // 
            this.btnFinish.Location = new System.Drawing.Point(469, 458);
            this.btnFinish.Name = "btnFinish";
            this.btnFinish.Size = new System.Drawing.Size(152, 41);
            this.btnFinish.TabIndex = 27;
            this.btnFinish.Text = "Finish";
            this.btnFinish.UseVisualStyleBackColor = true;
            this.btnFinish.Click += new System.EventHandler(this.btnFinish_Click);
            // 
            // Billing
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(800, 663);
            this.Controls.Add(this.btnFinish);
            this.Controls.Add(this.txtAmount);
            this.Controls.Add(this.txtAmossadaunt);
            this.Controls.Add(this.txtPrice);
            this.Controls.Add(this.sadsf);
            this.Controls.Add(this.txtProductname);
            this.Controls.Add(this.sad);
            this.Controls.Add(this.txtProductId);
            this.Controls.Add(this.asd);
            this.Controls.Add(this.txtUserId);
            this.Controls.Add(this.label);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtBillID);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "Billing";
            this.Text = "Billing";
            this.TextAlign = MetroFramework.Forms.MetroFormTextAlign.Center;
            this.Load += new System.EventHandler(this.Billing_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtBillID;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtUserId;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.TextBox txtProductId;
        private System.Windows.Forms.Label asd;
        private System.Windows.Forms.TextBox txtProductname;
        private System.Windows.Forms.Label sad;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.Label sadsf;
        private System.Windows.Forms.TextBox txtAmount;
        private System.Windows.Forms.Label txtAmossadaunt;
        private System.Windows.Forms.Button btnFinish;
    }
}