﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Farm_Automation.Forms
{
    public partial class CoopRegister : MetroFramework.Forms.MetroForm
    {
        public CoopRegister()
        {
            InitializeComponent();
        }
        private SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-6K2RTP8;Initial Catalog=ProjeVeri;Integrated Security=True");
        public int id;
        private void CoopRegister_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'projeVeriDataSet4.Coop' table. You can move, or remove it, as needed.
            this.coopTableAdapter.Fill(this.projeVeriDataSet4.Coop);
  
            getCoopRecord();
        }
        private bool isValid()
        {
            if (txtCoopId.Text == string.Empty)
            {
                MessageBox.Show("Please enter fields with correct paramaters.", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }
        private void getCoopRecord()
        {
            SqlCommand cmd = new SqlCommand("Select * from Coop", con);
            DataTable dt = new DataTable();

            con.Open();

            SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();
            dataGridCoopRegister.DataSource = dt;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (isValid())
                {
                    SqlCommand cmd = new SqlCommand("INSERT INTO Coop VALUES (@coop_id, @personnel_id, @coop_name, @capacity, @egg_production, @feed_consumption)", con);
                    cmd.CommandType = CommandType.Text;
                    int coop_id = int.Parse(txtCoopId.Text);
                    cmd.Parameters.AddWithValue("@coop_id", coop_id);
                    int personnel_id = int.Parse(txtPersonelId.Text);
                    cmd.Parameters.AddWithValue("@personnel_id", personnel_id);
                    cmd.Parameters.AddWithValue("@coop_name", txtCoopName.Text);
                    int capacity = int.Parse(txtCapacity.Text);
                    cmd.Parameters.AddWithValue("@capacity", capacity);
                    int egg_production = int.Parse(txtEggProd.Text);
                    cmd.Parameters.AddWithValue("@egg_production", egg_production);
                    decimal feed_consumption = decimal.Parse(txtFeedPro.Text);
                    cmd.Parameters.AddWithValue("@feed_consumption", feed_consumption);

                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("New Item is Adding", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    getCoopRecord();
                    refresh();

                }
                else
                {
                    MessageBox.Show("Please Select one of Them", "Save", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Incorrect enter");
            }
        }
        private void refresh()
        {
            txtCapacity.Clear();
            txtCoopId.Clear();
            txtCoopName.Clear();
            txtEggProd.Clear();
            txtFeedPro.Clear();
            txtPersonelId.Clear();
            txtCoopId.Focus();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("UPDATE Coop SET coop_id = @coop_id, personnel_id = @personnel_id, coop_name = @coop_name, capacity = @capacity, egg_production = @egg_production, feed_consumption = @feed_consumption WHERE coop_id = @coop_id", con);
                cmd.CommandType = CommandType.Text;
                int coop_id = int.Parse(txtCoopId.Text);
                cmd.Parameters.AddWithValue("@coop_id", coop_id);
                int personnel_id = int.Parse(txtPersonelId.Text);
                cmd.Parameters.AddWithValue("@personnel_id", personnel_id);
                cmd.Parameters.AddWithValue("@coop_name", txtCoopName.Text);
                int capacity = int.Parse(txtCapacity.Text);
                cmd.Parameters.AddWithValue("@capacity", capacity);
                int egg_production = int.Parse(txtEggProd.Text);
                cmd.Parameters.AddWithValue("@egg_production", egg_production);
                decimal feed_consumption = decimal.Parse(txtFeedPro.Text);
                cmd.Parameters.AddWithValue("@feed_consumption", feed_consumption);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("New Item is Adding", "Updated", MessageBoxButtons.OK, MessageBoxIcon.Information);
                getCoopRecord();
                refresh();
            }
            catch
            {
                MessageBox.Show("Please Select one of Them", "Update", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dataGridCoopRegister_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {

                txtCoopId.Text = dataGridCoopRegister.SelectedRows[0].Cells[0].Value.ToString();
                txtPersonelId.Text = dataGridCoopRegister.SelectedRows[0].Cells[1].Value.ToString();
                txtCoopName.Text = dataGridCoopRegister.SelectedRows[0].Cells[2].Value.ToString();
                txtCapacity.Text = dataGridCoopRegister.SelectedRows[0].Cells[3].Value.ToString();
                txtEggProd.Text = dataGridCoopRegister.SelectedRows[0].Cells[4].Value.ToString();
                txtFeedPro.Text = dataGridCoopRegister.SelectedRows[0].Cells[5].Value.ToString();        
            }
            catch
            {
                MessageBox.Show("Please Select one of Them", "Update", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("DELETE FROM Coop WHERE coop_id = @coop_id", con);
                cmd.CommandType = CommandType.Text;

                cmd.Parameters.AddWithValue("@coop_id", txtCoopId.Text);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Coop is Deleted", "Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);
                getCoopRecord();
                refresh();
            }
            catch
            {

            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            refresh();
        }
    }
}
