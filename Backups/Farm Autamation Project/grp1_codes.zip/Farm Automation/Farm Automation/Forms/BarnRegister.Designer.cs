﻿
namespace Farm_Automation.Forms
{
    partial class BarnRegister
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtPersonnelId = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtBarnName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtBarnId = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridBarnRegister = new System.Windows.Forms.DataGridView();
            this.barnidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.barnnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.personnelidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.barnBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.projeDataSet2 = new Farm_Automation.ProjeDataSet2();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.barnTableAdapter = new Farm_Automation.ProjeDataSet2TableAdapters.barnTableAdapter();
            this.metroSetControlBox1 = new MetroSet_UI.Controls.MetroSetControlBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridBarnRegister)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.barnBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.projeDataSet2)).BeginInit();
            this.SuspendLayout();
            // 
            // txtPersonnelId
            // 
            this.txtPersonnelId.Location = new System.Drawing.Point(292, 193);
            this.txtPersonnelId.Name = "txtPersonnelId";
            this.txtPersonnelId.Size = new System.Drawing.Size(224, 26);
            this.txtPersonnelId.TabIndex = 125;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(168, 193);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(118, 22);
            this.label5.TabIndex = 124;
            this.label5.Text = "Personnel ID:";
            // 
            // txtBarnName
            // 
            this.txtBarnName.Location = new System.Drawing.Point(292, 161);
            this.txtBarnName.Name = "txtBarnName";
            this.txtBarnName.Size = new System.Drawing.Size(224, 26);
            this.txtBarnName.TabIndex = 117;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(181, 161);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 22);
            this.label2.TabIndex = 116;
            this.label2.Text = "Barn Name:";
            // 
            // txtBarnId
            // 
            this.txtBarnId.Location = new System.Drawing.Point(292, 125);
            this.txtBarnId.Name = "txtBarnId";
            this.txtBarnId.Size = new System.Drawing.Size(224, 26);
            this.txtBarnId.TabIndex = 115;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(199, 126);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 22);
            this.label1.TabIndex = 114;
            this.label1.Text = "Barn ID:";
            // 
            // dataGridBarnRegister
            // 
            this.dataGridBarnRegister.AutoGenerateColumns = false;
            this.dataGridBarnRegister.BackgroundColor = System.Drawing.Color.LightSeaGreen;
            this.dataGridBarnRegister.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridBarnRegister.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.barnidDataGridViewTextBoxColumn,
            this.barnnameDataGridViewTextBoxColumn,
            this.personnelidDataGridViewTextBoxColumn});
            this.dataGridBarnRegister.DataSource = this.barnBindingSource;
            this.dataGridBarnRegister.Location = new System.Drawing.Point(106, 247);
            this.dataGridBarnRegister.Name = "dataGridBarnRegister";
            this.dataGridBarnRegister.Size = new System.Drawing.Size(513, 321);
            this.dataGridBarnRegister.TabIndex = 113;
            this.dataGridBarnRegister.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridBarnRegister_CellClick);
            // 
            // barnidDataGridViewTextBoxColumn
            // 
            this.barnidDataGridViewTextBoxColumn.DataPropertyName = "barn_id";
            this.barnidDataGridViewTextBoxColumn.HeaderText = "barn_id";
            this.barnidDataGridViewTextBoxColumn.Name = "barnidDataGridViewTextBoxColumn";
            this.barnidDataGridViewTextBoxColumn.Width = 150;
            // 
            // barnnameDataGridViewTextBoxColumn
            // 
            this.barnnameDataGridViewTextBoxColumn.DataPropertyName = "barn_name";
            this.barnnameDataGridViewTextBoxColumn.HeaderText = "barn_name";
            this.barnnameDataGridViewTextBoxColumn.Name = "barnnameDataGridViewTextBoxColumn";
            this.barnnameDataGridViewTextBoxColumn.Width = 170;
            // 
            // personnelidDataGridViewTextBoxColumn
            // 
            this.personnelidDataGridViewTextBoxColumn.DataPropertyName = "personnel_id";
            this.personnelidDataGridViewTextBoxColumn.HeaderText = "personnel_id";
            this.personnelidDataGridViewTextBoxColumn.Name = "personnelidDataGridViewTextBoxColumn";
            this.personnelidDataGridViewTextBoxColumn.Width = 150;
            // 
            // barnBindingSource
            // 
            this.barnBindingSource.DataMember = "barn";
            this.barnBindingSource.DataSource = this.projeDataSet2;
            // 
            // projeDataSet2
            // 
            this.projeDataSet2.DataSetName = "ProjeDataSet2";
            this.projeDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.Red;
            this.btnDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnDelete.Location = new System.Drawing.Point(363, 585);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(125, 43);
            this.btnDelete.TabIndex = 129;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnRefresh
            // 
            this.btnRefresh.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnRefresh.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefresh.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnRefresh.Location = new System.Drawing.Point(494, 585);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(125, 43);
            this.btnRefresh.TabIndex = 128;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.UseVisualStyleBackColor = false;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.BackColor = System.Drawing.Color.Green;
            this.btnUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdate.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnUpdate.Location = new System.Drawing.Point(232, 585);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(125, 43);
            this.btnUpdate.TabIndex = 127;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = false;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnSave.Location = new System.Drawing.Point(101, 585);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(125, 43);
            this.btnSave.TabIndex = 126;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // barnTableAdapter
            // 
            this.barnTableAdapter.ClearBeforeFill = true;
            // 
            // metroSetControlBox1
            // 
            this.metroSetControlBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.metroSetControlBox1.CloseHoverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(183)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.metroSetControlBox1.CloseHoverForeColor = System.Drawing.Color.White;
            this.metroSetControlBox1.CloseNormalForeColor = System.Drawing.Color.Gray;
            this.metroSetControlBox1.DisabledForeColor = System.Drawing.Color.DimGray;
            this.metroSetControlBox1.IsDerivedStyle = true;
            this.metroSetControlBox1.Location = new System.Drawing.Point(620, 4);
            this.metroSetControlBox1.MaximizeBox = true;
            this.metroSetControlBox1.MaximizeHoverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.metroSetControlBox1.MaximizeHoverForeColor = System.Drawing.Color.Gray;
            this.metroSetControlBox1.MaximizeNormalForeColor = System.Drawing.Color.Gray;
            this.metroSetControlBox1.MinimizeBox = true;
            this.metroSetControlBox1.MinimizeHoverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.metroSetControlBox1.MinimizeHoverForeColor = System.Drawing.Color.Gray;
            this.metroSetControlBox1.MinimizeNormalForeColor = System.Drawing.Color.Gray;
            this.metroSetControlBox1.Name = "metroSetControlBox1";
            this.metroSetControlBox1.Size = new System.Drawing.Size(100, 25);
            this.metroSetControlBox1.Style = MetroSet_UI.Enums.Style.Light;
            this.metroSetControlBox1.StyleManager = null;
            this.metroSetControlBox1.TabIndex = 130;
            this.metroSetControlBox1.Text = "metroSetControlBox1";
            this.metroSetControlBox1.ThemeAuthor = "Narwin";
            this.metroSetControlBox1.ThemeName = "MetroLite";
            // 
            // BarnRegister
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(720, 720);
            this.Controls.Add(this.metroSetControlBox1);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.txtPersonnelId);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtBarnName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtBarnId);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridBarnRegister);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "BarnRegister";
            this.Text = "Barn Register";
            this.TextAlign = MetroFramework.Forms.MetroFormTextAlign.Center;
            this.Load += new System.EventHandler(this.BarnRegister_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridBarnRegister)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.barnBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.projeDataSet2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtPersonnelId;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtBarnName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtBarnId;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridBarnRegister;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnSave;
        private ProjeDataSet2 projeDataSet2;
        private System.Windows.Forms.BindingSource barnBindingSource;
        private ProjeDataSet2TableAdapters.barnTableAdapter barnTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn barnidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn barnnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn personnelidDataGridViewTextBoxColumn;
        private MetroSet_UI.Controls.MetroSetControlBox metroSetControlBox1;
    }
}