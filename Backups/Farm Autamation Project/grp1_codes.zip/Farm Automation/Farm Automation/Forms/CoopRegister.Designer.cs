﻿
namespace Farm_Automation.Forms
{
    partial class CoopRegister
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.dataGridCoopRegister = new System.Windows.Forms.DataGridView();
            this.txtEggProd = new System.Windows.Forms.TextBox();
            this.txtFeedPro = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtCapacity = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtPersonelId = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtCoopId = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtCoopName = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.projeVeriDataSet4 = new Farm_Automation.ProjeVeriDataSet4();
            this.coopBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.coopTableAdapter = new Farm_Automation.ProjeVeriDataSet4TableAdapters.CoopTableAdapter();
            this.coopidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.personnelidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.coopnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.capacityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.eggproductionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.feedconsumptionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridCoopRegister)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.projeVeriDataSet4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.coopBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.Red;
            this.btnDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnDelete.Location = new System.Drawing.Point(520, 650);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(125, 43);
            this.btnDelete.TabIndex = 100;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnRefresh
            // 
            this.btnRefresh.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnRefresh.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefresh.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnRefresh.Location = new System.Drawing.Point(651, 650);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(125, 43);
            this.btnRefresh.TabIndex = 99;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.UseVisualStyleBackColor = false;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.BackColor = System.Drawing.Color.Green;
            this.btnUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdate.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnUpdate.Location = new System.Drawing.Point(389, 650);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(125, 43);
            this.btnUpdate.TabIndex = 98;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = false;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnSave.Location = new System.Drawing.Point(258, 650);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(125, 43);
            this.btnSave.TabIndex = 97;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // dataGridCoopRegister
            // 
            this.dataGridCoopRegister.AutoGenerateColumns = false;
            this.dataGridCoopRegister.BackgroundColor = System.Drawing.Color.LightSeaGreen;
            this.dataGridCoopRegister.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridCoopRegister.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.coopidDataGridViewTextBoxColumn,
            this.personnelidDataGridViewTextBoxColumn,
            this.coopnameDataGridViewTextBoxColumn,
            this.capacityDataGridViewTextBoxColumn,
            this.eggproductionDataGridViewTextBoxColumn,
            this.feedconsumptionDataGridViewTextBoxColumn});
            this.dataGridCoopRegister.DataSource = this.coopBindingSource;
            this.dataGridCoopRegister.Location = new System.Drawing.Point(43, 323);
            this.dataGridCoopRegister.Name = "dataGridCoopRegister";
            this.dataGridCoopRegister.Size = new System.Drawing.Size(939, 321);
            this.dataGridCoopRegister.TabIndex = 96;
            this.dataGridCoopRegister.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridCoopRegister_CellClick);
            // 
            // txtEggProd
            // 
            this.txtEggProd.Location = new System.Drawing.Point(580, 139);
            this.txtEggProd.Name = "txtEggProd";
            this.txtEggProd.Size = new System.Drawing.Size(224, 26);
            this.txtEggProd.TabIndex = 110;
            // 
            // txtFeedPro
            // 
            this.txtFeedPro.Location = new System.Drawing.Point(580, 171);
            this.txtFeedPro.Name = "txtFeedPro";
            this.txtFeedPro.Size = new System.Drawing.Size(224, 26);
            this.txtFeedPro.TabIndex = 109;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(423, 175);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(147, 22);
            this.label6.TabIndex = 108;
            this.label6.Text = "Feed Production:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(432, 139);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(138, 22);
            this.label3.TabIndex = 107;
            this.label3.Text = "Egg Production:";
            // 
            // txtCapacity
            // 
            this.txtCapacity.Location = new System.Drawing.Point(580, 103);
            this.txtCapacity.Name = "txtCapacity";
            this.txtCapacity.Size = new System.Drawing.Size(224, 26);
            this.txtCapacity.TabIndex = 106;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(485, 107);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(85, 22);
            this.label4.TabIndex = 105;
            this.label4.Text = "Capacity:";
            // 
            // txtPersonelId
            // 
            this.txtPersonelId.Location = new System.Drawing.Point(168, 139);
            this.txtPersonelId.Name = "txtPersonelId";
            this.txtPersonelId.Size = new System.Drawing.Size(224, 26);
            this.txtPersonelId.TabIndex = 104;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(50, 143);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(108, 22);
            this.label2.TabIndex = 103;
            this.label2.Text = "Personel ID:";
            // 
            // txtCoopId
            // 
            this.txtCoopId.Location = new System.Drawing.Point(168, 103);
            this.txtCoopId.Name = "txtCoopId";
            this.txtCoopId.Size = new System.Drawing.Size(224, 26);
            this.txtCoopId.TabIndex = 102;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(78, 107);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 22);
            this.label1.TabIndex = 101;
            this.label1.Text = "Coop ID:";
            // 
            // txtCoopName
            // 
            this.txtCoopName.Location = new System.Drawing.Point(168, 171);
            this.txtCoopName.Name = "txtCoopName";
            this.txtCoopName.Size = new System.Drawing.Size(224, 26);
            this.txtCoopName.TabIndex = 112;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(48, 172);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(110, 22);
            this.label5.TabIndex = 111;
            this.label5.Text = "Coop Name:";
            // 
            // projeVeriDataSet4
            // 
            this.projeVeriDataSet4.DataSetName = "ProjeVeriDataSet4";
            this.projeVeriDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // coopBindingSource
            // 
            this.coopBindingSource.DataMember = "Coop";
            this.coopBindingSource.DataSource = this.projeVeriDataSet4;
            // 
            // coopTableAdapter
            // 
            this.coopTableAdapter.ClearBeforeFill = true;
            // 
            // coopidDataGridViewTextBoxColumn
            // 
            this.coopidDataGridViewTextBoxColumn.DataPropertyName = "coop_id";
            this.coopidDataGridViewTextBoxColumn.HeaderText = "coop_id";
            this.coopidDataGridViewTextBoxColumn.Name = "coopidDataGridViewTextBoxColumn";
            this.coopidDataGridViewTextBoxColumn.Width = 130;
            // 
            // personnelidDataGridViewTextBoxColumn
            // 
            this.personnelidDataGridViewTextBoxColumn.DataPropertyName = "personnel_id";
            this.personnelidDataGridViewTextBoxColumn.HeaderText = "personnel_id";
            this.personnelidDataGridViewTextBoxColumn.Name = "personnelidDataGridViewTextBoxColumn";
            this.personnelidDataGridViewTextBoxColumn.Width = 130;
            // 
            // coopnameDataGridViewTextBoxColumn
            // 
            this.coopnameDataGridViewTextBoxColumn.DataPropertyName = "coop_name";
            this.coopnameDataGridViewTextBoxColumn.HeaderText = "coop_name";
            this.coopnameDataGridViewTextBoxColumn.Name = "coopnameDataGridViewTextBoxColumn";
            this.coopnameDataGridViewTextBoxColumn.Width = 150;
            // 
            // capacityDataGridViewTextBoxColumn
            // 
            this.capacityDataGridViewTextBoxColumn.DataPropertyName = "capacity";
            this.capacityDataGridViewTextBoxColumn.HeaderText = "capacity";
            this.capacityDataGridViewTextBoxColumn.Name = "capacityDataGridViewTextBoxColumn";
            this.capacityDataGridViewTextBoxColumn.Width = 150;
            // 
            // eggproductionDataGridViewTextBoxColumn
            // 
            this.eggproductionDataGridViewTextBoxColumn.DataPropertyName = "egg_production";
            this.eggproductionDataGridViewTextBoxColumn.HeaderText = "egg_production";
            this.eggproductionDataGridViewTextBoxColumn.Name = "eggproductionDataGridViewTextBoxColumn";
            this.eggproductionDataGridViewTextBoxColumn.Width = 170;
            // 
            // feedconsumptionDataGridViewTextBoxColumn
            // 
            this.feedconsumptionDataGridViewTextBoxColumn.DataPropertyName = "feed_consumption";
            this.feedconsumptionDataGridViewTextBoxColumn.HeaderText = "feed_consumption";
            this.feedconsumptionDataGridViewTextBoxColumn.Name = "feedconsumptionDataGridViewTextBoxColumn";
            this.feedconsumptionDataGridViewTextBoxColumn.Width = 170;
            // 
            // CoopRegister
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1024, 720);
            this.Controls.Add(this.txtCoopName);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtEggProd);
            this.Controls.Add(this.txtFeedPro);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtCapacity);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtPersonelId);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtCoopId);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.dataGridCoopRegister);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "CoopRegister";
            this.Text = "Coop Register";
            this.TextAlign = MetroFramework.Forms.MetroFormTextAlign.Center;
            this.Load += new System.EventHandler(this.CoopRegister_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridCoopRegister)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.projeVeriDataSet4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.coopBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.DataGridView dataGridCoopRegister;
        private System.Windows.Forms.TextBox txtEggProd;
        private System.Windows.Forms.TextBox txtFeedPro;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtCapacity;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtPersonelId;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtCoopId;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtCoopName;
        private System.Windows.Forms.Label label5;
        private ProjeVeriDataSet4 projeVeriDataSet4;
        private System.Windows.Forms.BindingSource coopBindingSource;
        private ProjeVeriDataSet4TableAdapters.CoopTableAdapter coopTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn coopidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn personnelidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn coopnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn capacityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn eggproductionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn feedconsumptionDataGridViewTextBoxColumn;
    }
}