﻿using Farm_Automation.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Farm_Automation.Forms
{
    public partial class signUp : MetroFramework.Forms.MetroForm
    {
        DataAccess dao;
        public signUp()
        {
            InitializeComponent();
            dao = new DataAccess();
        }
        private SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-6K2RTP8;Initial Catalog=ProjeVeri;Integrated Security=True");
        public int id;
        private void signUp_Load(object sender, EventArgs e)
        {
            
        }
    

        private void btnSave_Click(object sender, EventArgs e)
        {
            //try
            //{
                if (txtPassword.Text != txtConfirmPass.Text)
                {
                    MessageBox.Show("Password not match");
                    return;
                }
                if (!dao.SignUp(txtEmail.Text, txtPassword.Text, txtFullname.Text, txtSSN.Text, txtPhone.Text, txtUsername.Text))
                {
                    MessageBox.Show("Register failed");
                    return;
                }
                VerifyTokenForm form = new VerifyTokenForm();
                form.Email = txtEmail.Text;
                form.Pw = txtPassword.Text;
                form.nameSurname = txtFullname.Text;
                form.ssn = txtSSN.Text;
                form.telNo = txtPhone.Text;
                form.username = txtUsername.Text;
                
            

                if (form.ShowDialog() == DialogResult.OK)
                {
                    MessageBox.Show("Verifed done");     
                    Form1 frm1 = new Form1();
                    frm1.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Please Select one of Them", "Save", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                
            //}
            //catch (Exception)
            //{
            //    MessageBox.Show("Incorrect enter");
            //}
        }
    }
}
