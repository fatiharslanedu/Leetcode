﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Farm_Automation.Forms
{
    public partial class PoultryRegister : MetroFramework.Forms.MetroForm
    {

        public PoultryRegister()
        {
            InitializeComponent();
        }
        private SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-6K2RTP8;Initial Catalog=ProjeVeri;Integrated Security=True");
        public int id;
        private void PoultryRegister_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'projeVeriDataSet5.Props_Poultry' table. You can move, or remove it, as needed.
            this.props_PoultryTableAdapter.Fill(this.projeVeriDataSet5.Props_Poultry);

            getPoultryRecord();
        }
        private bool isValid()
        {
            if (txtBirdId.Text == string.Empty)
            {
                MessageBox.Show("Please enter fields with correct paramaters.", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        private void getPoultryRecord()
        {
            SqlCommand cmd = new SqlCommand("Select * from Props_Poultry", con);
            DataTable dt = new DataTable();

            con.Open();

            SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();

            dataGridPoultryRegister.DataSource = dt;
        }
        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (isValid())
                {
                    SqlCommand cmd = new SqlCommand("INSERT INTO Props_Poultry VALUES (@bird_id, @animal_type, @coop_id, @breed, @price, @weight, @amountOf_meat)", con);
                    cmd.CommandType = CommandType.Text;
                    int bird_id = int.Parse(txtBirdId.Text);
                    cmd.Parameters.AddWithValue("@bird_id", bird_id);
                    int animal_type = int.Parse(txtAnimalType.Text);
                    cmd.Parameters.AddWithValue("@animal_type", animal_type);
                    int coop_id = int.Parse(txtCoopId.Text);
                    cmd.Parameters.AddWithValue("@coop_id", coop_id);             
                    cmd.Parameters.AddWithValue("@breed", txtBreed.Text);
                    decimal price = decimal.Parse(txtPrice.Text);
                    cmd.Parameters.AddWithValue("@price", price);
                    decimal weight = decimal.Parse(txtWeight.Text);
                    cmd.Parameters.AddWithValue("@weight", weight);
                    decimal amountMeat = decimal.Parse(txtAmountofMeat.Text);
                    cmd.Parameters.AddWithValue("@amountOf_meat", amountMeat);
                    
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("New Item is Adding", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    getPoultryRecord();
                    refresh();

                }
                else
                {
                    MessageBox.Show("Please Select one of Them", "Update", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Incorrect enter");
            }
        }
        private void refresh()
        {
            txtAmountofMeat.Clear();
            txtAnimalType.Clear();
            txtBirdId.Clear();
            txtBreed.Clear();
            txtCoopId.Clear();
            txtPrice.Clear();
            txtWeight.Clear();
            txtBirdId.Focus();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("UPDATE Props_Poultry SET bird_id = @bird_id,animal_type = @animal_type,coop_id= @coop_id,breed= @breed, price= @price, weight= @weight,amountOf_meat = @amountOf_meat WHERE bird_id = @bird_id", con);
                cmd.CommandType = CommandType.Text;
                int bird_id = int.Parse(txtBirdId.Text);
                cmd.Parameters.AddWithValue("@bird_id", bird_id);
                int animal_type = int.Parse(txtAnimalType.Text);
                cmd.Parameters.AddWithValue("@animal_type", animal_type);
                int coop_id = int.Parse(txtCoopId.Text);
                cmd.Parameters.AddWithValue("@coop_id", coop_id);
                cmd.Parameters.AddWithValue("@breed", txtBreed.Text);
                decimal price = decimal.Parse(txtPrice.Text);
                cmd.Parameters.AddWithValue("@price", price);
                decimal weight = decimal.Parse(txtWeight.Text);
                cmd.Parameters.AddWithValue("@weight", weight);
                decimal amountMeat = decimal.Parse(txtAmountofMeat.Text);
                cmd.Parameters.AddWithValue("@amountOf_meat", amountMeat);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("New Item is Updated", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
                getPoultryRecord();
                refresh();
            }
            catch
            {
                MessageBox.Show("Please Select one of Them", "Update", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dataGridPoultryRegister_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                txtBirdId.Text = dataGridPoultryRegister.SelectedRows[0].Cells[0].Value.ToString();
                txtAnimalType.Text = dataGridPoultryRegister.SelectedRows[0].Cells[1].Value.ToString();
                txtCoopId.Text = dataGridPoultryRegister.SelectedRows[0].Cells[2].Value.ToString();
                txtBreed.Text = dataGridPoultryRegister.SelectedRows[0].Cells[3].Value.ToString();
                txtPrice.Text = dataGridPoultryRegister.SelectedRows[0].Cells[4].Value.ToString();
                txtWeight.Text = dataGridPoultryRegister.SelectedRows[0].Cells[5].Value.ToString();
                txtAmountofMeat.Text = dataGridPoultryRegister.SelectedRows[0].Cells[6].Value.ToString();
            }
            catch
            {
                
            }
           
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            refresh();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("DELETE FROM Props_Poultry WHERE bird_id = @bird_id", con);
                cmd.CommandType = CommandType.Text;

                cmd.Parameters.AddWithValue("@bird_id", txtBirdId.Text);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Poultry is Deleted", "Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);
                getPoultryRecord();
                refresh();
            }
            catch
            {

            }
            
        }
    }
}
