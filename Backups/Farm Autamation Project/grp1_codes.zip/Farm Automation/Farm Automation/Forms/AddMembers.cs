﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Farm_Automation.Forms
{
    public partial class AddMembers : MetroFramework.Forms.MetroForm
    {
        public AddMembers()
        {
            InitializeComponent();
        }
        private SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-6K2RTP8;Initial Catalog=ProjeVeri;Integrated Security=True");
        public int id;
        private void AddMembers_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'projeVeriDataSet3.Staff_Members' table. You can move, or remove it, as needed.
            this.staff_MembersTableAdapter.Fill(this.projeVeriDataSet3.Staff_Members);
            getStaffRecord();
        }

        private void getStaffRecord()
        {
            SqlCommand cmd = new SqlCommand("Select * from Staff_Members", con);
            DataTable dt = new DataTable();

            con.Open();

            SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();
            dataGridAddMembers.DataSource = dt;
        }
        private bool isValid()
        {
            if (txtPersonnelId.Text == string.Empty)
            {
                MessageBox.Show("Please enter fields with correct paramaters.", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (isValid())
                {
                    SqlCommand cmd = new SqlCommand("INSERT INTO Staff_Members VALUES (@personnel_id, @personnel_name, @personnel_surname, @birthDate, @speciality, @email, @tel_no, @start_dateOf_employee, @salary)", con);
                    cmd.CommandType = CommandType.Text;
                    int personnel_id = int.Parse(txtPersonnelId.Text);
                    cmd.Parameters.AddWithValue("@personnel_id", personnel_id);
                    cmd.Parameters.AddWithValue("@personnel_name", txtPersonelName.Text);
                    cmd.Parameters.AddWithValue("@personnel_surname", txtPersonnelSurname.Text);
                    cmd.Parameters.AddWithValue("@birthDate", txtAge.Text);
                    cmd.Parameters.AddWithValue("@speciality", txtSpeciality.Text);
                    cmd.Parameters.AddWithValue("@email", txtEmail.Text);
                    cmd.Parameters.AddWithValue("@tel_no", txtPhone.Text);
                    cmd.Parameters.AddWithValue("@start_dateOf_employee", txtStart.Text);
                    decimal salary = decimal.Parse(txtSalary.Text);
                    cmd.Parameters.AddWithValue("@salary", salary);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("New Item is Adding", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    getStaffRecord();
                    refresh();
                }
                else
                {
                    MessageBox.Show("Please Select one of Them", "Save", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
        }
            catch (Exception)
            {
                MessageBox.Show("Incorrect enter");
            }
}
        private void refresh()
        {
            txtAge.Clear();
            txtEmail.Clear();
            txtPersonelName.Clear();
            txtPersonnelId.Clear();
            txtPersonnelSurname.Clear();
            txtStart.Clear();
            txtPhone.Clear();
            txtSpeciality.Clear();
            txtSalary.Clear();
            txtPersonnelId.Focus();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("UPDATE  Staff_Members SET personnel_id = @personnel_id, personnel_name = @personnel_name, personnel_surname = @personnel_surname, birthDate = @birthDate, speciality = @speciality, email = @email,tel_no = @tel_no, start_dateOf_employee = @start_dateOf_employee,salary = @salary WHERE personnel_id = @personnel_id ", con);
                cmd.CommandType = CommandType.Text;
                int personnel_id = int.Parse(txtPersonnelId.Text);
                cmd.Parameters.AddWithValue("@personnel_id", personnel_id);
                cmd.Parameters.AddWithValue("@personnel_name", txtPersonelName.Text);
                cmd.Parameters.AddWithValue("@personnel_surname", txtPersonnelSurname.Text);
                cmd.Parameters.AddWithValue("@birthDate", txtAge.Text);
                cmd.Parameters.AddWithValue("@speciality", txtSpeciality.Text);
                cmd.Parameters.AddWithValue("@email", txtEmail.Text);
                cmd.Parameters.AddWithValue("@tel_no", txtPhone.Text);
                cmd.Parameters.AddWithValue("@start_dateOf_employee", txtStart.Text);
                decimal salary = decimal.Parse(txtSalary.Text);
                cmd.Parameters.AddWithValue("@salary", salary);


                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("New Item is Updated", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
                getStaffRecord();
                refresh();
            }
            catch
            {
                MessageBox.Show("Incorrect enter");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("DELETE FROM Staff_Members WHERE personnel_id = @personnel_id", con);
                cmd.CommandType = CommandType.Text;

                cmd.Parameters.AddWithValue("@personnel_id", txtPersonnelId.Text);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Staff Member deleted", "Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);
                getStaffRecord();
                refresh();
            }
            catch
            {

            }
        }

        private void dataGridAddMembers_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {

                txtPersonnelId.Text = dataGridAddMembers.SelectedRows[0].Cells[0].Value.ToString();
                txtPersonelName.Text = dataGridAddMembers.SelectedRows[0].Cells[1].Value.ToString();
                txtPersonnelSurname.Text = dataGridAddMembers.SelectedRows[0].Cells[2].Value.ToString();
                txtAge.Text = dataGridAddMembers.SelectedRows[0].Cells[3].Value.ToString();
                txtSpeciality.Text = dataGridAddMembers.SelectedRows[0].Cells[4].Value.ToString();
                txtEmail.Text = dataGridAddMembers.SelectedRows[0].Cells[5].Value.ToString();
                txtPhone.Text = dataGridAddMembers.SelectedRows[0].Cells[6].Value.ToString();
                txtStart.Text = dataGridAddMembers.SelectedRows[0].Cells[7].Value.ToString();
                txtSalary.Text = dataGridAddMembers.SelectedRows[0].Cells[8].Value.ToString();
            }
            catch
            {
               
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            refresh();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtAge_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPersonnelSurname_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPersonelName_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPersonnelId_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtEmail_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPhone_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtStart_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtSalary_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
