﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Farm_Automation.Forms
{
    public partial class AnimalRegister : MetroFramework.Forms.MetroForm
    {
        
        
        public AnimalRegister()
        {
            InitializeComponent();
            
        }
        private SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-6K2RTP8;Initial Catalog=ProjeVeri;Integrated Security=True");
        public int id;
        private void AnimalRegister_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'projeVeriDataSet.Props_Mammal_Animal' table. You can move, or remove it, as needed.
            this.props_Mammal_AnimalTableAdapter.Fill(this.projeVeriDataSet.Props_Mammal_Animal);
            getMammalRecord();
        }
        private bool isValid()
        {
            if (txtEarringId.Text == string.Empty)
            {
                MessageBox.Show("Please enter fields with correct paramaters.", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }
        private void getMammalRecord()
        {
            SqlCommand cmd = new SqlCommand("Select * from Props_Mammal_Animal", con);
            DataTable dt = new DataTable();

            con.Open();

            SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();

            dataGridPoultryRegister.DataSource = dt;
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (isValid())
                {
                    SqlCommand cmd = new SqlCommand("INSERT INTO Props_Mammal_Animal VALUES (@earring_id, @animal_type, @barn_id, @birthDate, @gender, @breed, @weight, @price)", con);
                    cmd.CommandType = CommandType.Text;
                    int earring_id = int.Parse(txtEarringId.Text);
                    cmd.Parameters.AddWithValue("@earring_id", earring_id);
                    int animal_type = int.Parse(txtAnimalType.Text);
                    cmd.Parameters.AddWithValue("@animal_type", animal_type);
                    int barn_id = int.Parse(txtBarnId.Text);
                    cmd.Parameters.AddWithValue("@barn_id", barn_id);            
                    cmd.Parameters.AddWithValue("@birthDate", txtBornDate.Text);
                    cmd.Parameters.AddWithValue("@gender", txtGender.Text);
                    cmd.Parameters.AddWithValue("@breed", txtBreed.Text);  
                    decimal weight = decimal.Parse(txtWeight.Text);
                    cmd.Parameters.AddWithValue("@weight", weight);
                    decimal price = decimal.Parse(txtPrice.Text);
                    cmd.Parameters.AddWithValue("@price", price);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("New Item is Adding", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    getMammalRecord();
                    refresh();

                }
                else
                {
                    MessageBox.Show("Please Select one of Them", "Update", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Incorrect enter");
            }
        }

        private void refresh()
        {
            txtPrice.Clear();
            txtAnimalType.Clear();
            txtBarnId.Clear();
            txtBornDate.Clear();
            txtBreed.Clear();
            txtEarringId.Clear();
            txtGender.Clear();
            txtWeight.Clear();
            txtEarringId.Focus();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            //@earring_id, @animal_type, @barn_id, @born_date, @gender, @breed, @weight, @amountOf_meat, @price
            try
            {
                SqlCommand cmd = new SqlCommand("UPDATE Props_Mammal_Animal SET earring_id = @earring_id, animal_type = @animal_type, barn_id = @barn_id, birthDate = @birthDate, gender = @gender, breed = @breed, weight = @weight, price = @price WHERE earring_id = @earring_id", con);
                cmd.CommandType = CommandType.Text;
                int earring_id = int.Parse(txtEarringId.Text);
                cmd.Parameters.AddWithValue("@earring_id", earring_id);
                int animal_type = int.Parse(txtAnimalType.Text);
                cmd.Parameters.AddWithValue("@animal_type", animal_type);
                int barn_id = int.Parse(txtBarnId.Text);
                cmd.Parameters.AddWithValue("@barn_id", barn_id);
                cmd.Parameters.AddWithValue("@birthDate", txtBornDate.Text);
                cmd.Parameters.AddWithValue("@gender", txtGender.Text);
                cmd.Parameters.AddWithValue("@breed", txtBreed.Text);
                decimal weight = decimal.Parse(txtWeight.Text);
                cmd.Parameters.AddWithValue("@weight", weight);           
                decimal price = decimal.Parse(txtPrice.Text);
                cmd.Parameters.AddWithValue("@price", price);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("New Item is Updated", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
                getMammalRecord();
                refresh();
            }
            catch
            {
                MessageBox.Show("Please Select one of Them", "Update", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dataGridAnimalRegister_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                
                txtEarringId.Text = dataGridPoultryRegister.SelectedRows[0].Cells[0].Value.ToString();
                txtAnimalType.Text = dataGridPoultryRegister.SelectedRows[0].Cells[1].Value.ToString();
                txtBarnId.Text = dataGridPoultryRegister.SelectedRows[0].Cells[2].Value.ToString();
                txtBornDate.Text = dataGridPoultryRegister.SelectedRows[0].Cells[3].Value.ToString();
                txtGender.Text = dataGridPoultryRegister.SelectedRows[0].Cells[4].Value.ToString();
                txtBreed.Text = dataGridPoultryRegister.SelectedRows[0].Cells[5].Value.ToString();
                txtWeight.Text = dataGridPoultryRegister.SelectedRows[0].Cells[6].Value.ToString();     
                txtPrice.Text = dataGridPoultryRegister.SelectedRows[0].Cells[7].Value.ToString();
            }
            catch
            {
                MessageBox.Show("Please Select one of Them", "Update", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            refresh();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("DELETE FROM Props_Mammal_Animal WHERE earring_id = @earring_id", con);
            cmd.CommandType = CommandType.Text;

            cmd.Parameters.AddWithValue("@earring_id", txtEarringId.Text);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Mammal is Deleted", "Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);
            getMammalRecord();
            refresh();
        }
    }
}
