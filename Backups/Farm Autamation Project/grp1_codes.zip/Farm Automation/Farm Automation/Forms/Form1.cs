﻿using Farm_Automation.Classes;
using Farm_Automation.Forms;
using RegisterForm;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Farm_Automation
{
  
    public partial class Form1 : Form
    {
        SqlConnection con = new SqlConnection();
        SqlCommand com = new SqlCommand();
        DataAccess dao;
        public Form1()
        {
            InitializeComponent();
            con.ConnectionString = @"Data Source=DESKTOP-6K2RTP8;Initial Catalog=ProjeVeri;Integrated Security=True";
            dao = new DataAccess();
        }

        

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void BtnExit_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
        public void keepTable()
        {
            try
            {      
                    SqlCommand cmd1 = new SqlCommand("INSERT INTO tempUsername VALUES(@username)", con);
                    cmd1.CommandType = CommandType.Text; 
                    cmd1.Parameters.AddWithValue("@username", txtBoxUsername);
                   
                    con.Close();            
            }
            catch (Exception)
            {
                MessageBox.Show("Incorrect enter");
            }
        }
        private void logButton_Click(object sender, EventArgs e)
        {
            try {
                LoginStatus loginStatus = dao.CheckLogin2(txtBoxUsername.Text, txtBoxPassword.Text);
                if (loginStatus == LoginStatus.OK)
                {
                    MessageBox.Show("Your're logged");
                    Form_Dashboard form_Dashboard = new Form_Dashboard();
                    keepTable();
                    form_Dashboard.ShowDialog();
                    this.Dispose();
                }
                else
                {
                    MessageBox.Show("Login failed");
                }
            }
            catch(Exception)
            {
                MessageBox.Show("Incorrect enter");
                con.Close();
            }
            
            
        }

        private void lblForgetPassword_Click(object sender, EventArgs e)
        {

        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }
        Point lastPoint;

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void btnSignUp_Click(object sender, EventArgs e)
        {
            using(signUp sign = new signUp())
            {
                
                sign.ShowDialog();
                this.Dispose();
            }
            
        }

        private void BtnGoogle_Click(object sender, EventArgs e)
        {
            using (googleSignIn googleSignIn = new googleSignIn())
            {
                googleSignIn.ShowDialog();
                this.Dispose();
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
