﻿using System.Net;
using System.Net.Mail;

namespace Farm_Automation.Classes
{
    internal class EmailRegister
    {
        SmtpClient smtpClient;
        static string fromMail = "school417256@gmail.com";
        static string password = "mkal858858";
        public EmailRegister()
        {
            smtpClient = new SmtpClient()
            {
                Host = "smtp.gmail.com",
                Port = 587,
                EnableSsl = true,
                DeliveryMethod = SmtpDeliveryMethod.Network,
                UseDefaultCredentials = false,
                Credentials = new NetworkCredential(fromMail, password)
            };
        }
        public void Send(string body, string toAddr)
        {
            try
            {
                using (var m = new MailMessage(fromMail, toAddr)
                {
                    Subject = "Register",
                    Body = body,
                })
                {
                    m.IsBodyHtml = true;
                    smtpClient.Send(m);
                }
            }
            catch
            {
                
            }
            
        }
    }
}