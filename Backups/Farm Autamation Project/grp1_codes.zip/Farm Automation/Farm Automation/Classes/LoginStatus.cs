﻿namespace RegisterForm
{
    public enum LoginStatus
    {
        NotExist,
        NeedVerify,
        Incorrect,
        OK,
    }
}