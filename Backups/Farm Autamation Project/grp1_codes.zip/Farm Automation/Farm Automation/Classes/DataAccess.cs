﻿using RegisterForm;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Farm_Automation.Classes
{
    class DataAccess
    {
        private static string salt = "key";
        private SqlConnection GetConnection
            => new SqlConnection(@"Data Source=DESKTOP-6K2RTP8;Initial Catalog=ProjeVeri;Integrated Security=True");

        private string GenerateHash(string password)
        {
            byte[] bytes = Encoding.UTF8.GetBytes(password + salt);
            SHA256Managed sha = new SHA256Managed();
            byte[] hash = sha.ComputeHash(bytes);
            return Convert.ToBase64String(hash);
        }
        public LoginStatus CheckLogin(string email, string pw)
        {
            using (var c = GetConnection)
            {
                c.Open();
                var cmd =
                    new SqlCommand("SELECT * FROM SignUp WHERE email=@email AND password=@pw", c);
                var hash = GenerateHash(pw);
                cmd.Parameters.AddWithValue("@email", email);
                cmd.Parameters.AddWithValue("@pw", hash);
                using (var read = cmd.ExecuteReader())
                {
                    if (read.Read())
                    {
                        if (!string.IsNullOrEmpty(read["code"] + string.Empty))
                        {
                            return LoginStatus.NeedVerify;
                        }
                        else if (!string.IsNullOrEmpty(read["email"] + string.Empty))
                        {
                            return LoginStatus.OK;
                        }
                        else
                        {
                            return LoginStatus.Incorrect;
                        }
                    }
                }
            }
            return LoginStatus.NotExist;
        }
        public LoginStatus CheckLogin2(string username, string pw)
        {
            using (var c = GetConnection)
            {
                c.Open();
                var cmd =
                    new SqlCommand("SELECT * FROM SignUp WHERE username=@username AND password=@pw", c);
                var hash = GenerateHash(pw);
                cmd.Parameters.AddWithValue("@username", username);
                cmd.Parameters.AddWithValue("@pw", hash);
                using (var read = cmd.ExecuteReader())
                {
                    if (read.Read())
                    {
                        if (!string.IsNullOrEmpty(read["code"] + string.Empty))
                        {
                            return LoginStatus.NeedVerify;
                        }
                        else if (!string.IsNullOrEmpty(read["username"] + string.Empty))
                        {
                            return LoginStatus.OK;
                        }
                        else
                        {
                            return LoginStatus.Incorrect;
                        }
                    }
                }
            }
            return LoginStatus.NotExist;
        }

        public bool SignUp(string email, string pw, string nameSurname, string ssn, string telNo, string username)
        {
            LoginStatus loginStatus = CheckLogin(email, pw);
            if (loginStatus == LoginStatus.NotExist)
            {
                using (var c = GetConnection)
                {
                    c.Open();
                    var hash = GenerateHash(pw);
                    var code = new Random().Next(9999);
                    var cmd = new SqlCommand("INSERT INTO SignUp(email,password,code, nameSurname, ssn, telNo, username) VALUES(@email,@pw,@code, @nameSurname, @ssn, @telNo, @username)", c);
                    cmd.Parameters.AddWithValue("@email", email);
                    cmd.Parameters.AddWithValue("@pw", hash);
                    cmd.Parameters.AddWithValue("@code", code);
                    cmd.Parameters.AddWithValue("@nameSurname", nameSurname);
                    cmd.Parameters.AddWithValue("@ssn", ssn);
                    cmd.Parameters.AddWithValue("@telNo", telNo);
                    cmd.Parameters.AddWithValue("@username", username);
                    var mailhelp = new EmailRegister();
                    mailhelp.Send(code + string.Empty, email);
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
            return false;
        }
        public bool VerifyCode(string email, string pw, string code)
        {
            LoginStatus loginStatus = CheckLogin(email, pw);
            if (loginStatus != LoginStatus.NeedVerify) return false;
            using (var c = GetConnection)
            {
                c.Open();
                var cmd = new SqlCommand("SELECT code FROM SignUp WHERE email=@email", c);
                cmd.Parameters.AddWithValue("@email", email);
                if (cmd.ExecuteScalar().ToString() == code)
                {
                    var cmdUpdate =
                        new SqlCommand("UPDATE SignUp SET code = NULL WHERE email=@email", c);
                    cmdUpdate.Parameters.AddWithValue("@email", email);
                    return cmdUpdate.ExecuteNonQuery() > 0;
                }
            }
            return false;
        }
    }
}
