﻿using Farm_Automation.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Farm_Automation.UserControls
{
    public partial class Users : UserControl
    {
        public Users()
        {
            InitializeComponent();
            dataGridUsers.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.Fill);
            dataGridUsers.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            dataGridUsers.AllowUserToOrderColumns = true;
            dataGridUsers.AllowUserToResizeColumns = true;
        }
        private SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-6K2RTP8;Initial Catalog=ProjeVeri;Integrated Security=True");
        public int id;
        private void btnAddMembers_Click(object sender, EventArgs e)
        {
            using (AddMembers addMembers = new AddMembers())
            {
                addMembers.ShowDialog();
            }
        }
        private void getStaffRecord()
        {
            SqlCommand cmd = new SqlCommand("Select * from Staff_Members", con);
            DataTable dt = new DataTable();

            con.Open();

            SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();
            dataGridUsers.DataSource = dt;
        }
        private void dataGridUsers_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Users_Load(object sender, EventArgs e)
        {
            getStaffRecord();
        }
    }
}
