﻿using Farm_Automation.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Farm_Automation.UserControls
{
   
    public partial class UC_Register : UserControl
    {
        public UC_Register()
        {
            InitializeComponent();
            getMammalRecord();
        }
        private SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-6K2RTP8;Initial Catalog=ProjeVeri;Integrated Security=True");
        public int id;
        private void button2_Click(object sender, EventArgs e)
        {
            using (PoultryRegister poultryRegister = new PoultryRegister())
            {
                poultryRegister.ShowDialog();
            }
        }
        private void getMammalRecord()
        {
            SqlCommand cmd = new SqlCommand("Select * from Props_Mammal_Animal", con);
            DataTable dt = new DataTable();

            con.Open();

            SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();

            dataGridRegister.DataSource = dt;
        }
        private void btnRegisterAnimal_Click(object sender, EventArgs e)
        {
            using(AnimalRegister animalRegister = new AnimalRegister())
            {
                animalRegister.ShowDialog();
            }
        }

        private void btnCoop_Click(object sender, EventArgs e)
        {
            using (CoopRegister coopRegister = new CoopRegister())
            {
                coopRegister.ShowDialog();
            }
        }

        private void btnBarn_Click(object sender, EventArgs e)
        {
            using (BarnRegister barnRegister = new BarnRegister())
            {
                barnRegister.ShowDialog();
            }
        }

        private void dataGridRegister_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
