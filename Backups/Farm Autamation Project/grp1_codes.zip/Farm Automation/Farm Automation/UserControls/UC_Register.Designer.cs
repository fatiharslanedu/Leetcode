﻿
namespace Farm_Automation.UserControls
{
    partial class UC_Register
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_Register));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnBarn = new System.Windows.Forms.Button();
            this.btnCoop = new System.Windows.Forms.Button();
            this.btnPoultryRegister = new System.Windows.Forms.Button();
            this.btnRegisterAnimal = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.dataGridRegister = new System.Windows.Forms.DataGridView();
            this.projeVeriDataSet6 = new Farm_Automation.ProjeVeriDataSet6();
            this.propsMammalAnimalBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.props_Mammal_AnimalTableAdapter = new Farm_Automation.ProjeVeriDataSet6TableAdapters.Props_Mammal_AnimalTableAdapter();
            this.earringidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.animaltypeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.barnidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.birthDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.genderDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.breedDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.weightDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridRegister)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.projeVeriDataSet6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.propsMammalAnimalBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.btnBarn);
            this.panel1.Controls.Add(this.btnCoop);
            this.panel1.Controls.Add(this.btnPoultryRegister);
            this.panel1.Controls.Add(this.btnRegisterAnimal);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1146, 112);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // btnBarn
            // 
            this.btnBarn.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnBarn.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBarn.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnBarn.Location = new System.Drawing.Point(118, 11);
            this.btnBarn.Name = "btnBarn";
            this.btnBarn.Size = new System.Drawing.Size(121, 90);
            this.btnBarn.TabIndex = 4;
            this.btnBarn.Text = "Add Barn";
            this.btnBarn.UseVisualStyleBackColor = false;
            this.btnBarn.Click += new System.EventHandler(this.btnBarn_Click);
            // 
            // btnCoop
            // 
            this.btnCoop.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnCoop.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCoop.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnCoop.Location = new System.Drawing.Point(245, 11);
            this.btnCoop.Name = "btnCoop";
            this.btnCoop.Size = new System.Drawing.Size(121, 90);
            this.btnCoop.TabIndex = 3;
            this.btnCoop.Text = "Add Coop";
            this.btnCoop.UseVisualStyleBackColor = false;
            this.btnCoop.Click += new System.EventHandler(this.btnCoop_Click);
            // 
            // btnPoultryRegister
            // 
            this.btnPoultryRegister.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnPoultryRegister.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPoultryRegister.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnPoultryRegister.Location = new System.Drawing.Point(1012, 11);
            this.btnPoultryRegister.Name = "btnPoultryRegister";
            this.btnPoultryRegister.Size = new System.Drawing.Size(121, 90);
            this.btnPoultryRegister.TabIndex = 2;
            this.btnPoultryRegister.Text = "Poultry Register";
            this.btnPoultryRegister.UseVisualStyleBackColor = false;
            this.btnPoultryRegister.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnRegisterAnimal
            // 
            this.btnRegisterAnimal.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnRegisterAnimal.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegisterAnimal.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnRegisterAnimal.Location = new System.Drawing.Point(885, 11);
            this.btnRegisterAnimal.Name = "btnRegisterAnimal";
            this.btnRegisterAnimal.Size = new System.Drawing.Size(121, 90);
            this.btnRegisterAnimal.TabIndex = 1;
            this.btnRegisterAnimal.Text = "Animal Register";
            this.btnRegisterAnimal.UseVisualStyleBackColor = false;
            this.btnRegisterAnimal.Click += new System.EventHandler(this.btnRegisterAnimal_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(505, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(137, 28);
            this.label1.TabIndex = 1;
            this.label1.Text = "Animal List";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(3, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(109, 106);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // dataGridRegister
            // 
            this.dataGridRegister.AutoGenerateColumns = false;
            this.dataGridRegister.BackgroundColor = System.Drawing.Color.LightSeaGreen;
            this.dataGridRegister.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridRegister.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.earringidDataGridViewTextBoxColumn,
            this.animaltypeDataGridViewTextBoxColumn,
            this.barnidDataGridViewTextBoxColumn,
            this.birthDateDataGridViewTextBoxColumn,
            this.genderDataGridViewTextBoxColumn,
            this.breedDataGridViewTextBoxColumn,
            this.weightDataGridViewTextBoxColumn,
            this.priceDataGridViewTextBoxColumn});
            this.dataGridRegister.DataSource = this.propsMammalAnimalBindingSource;
            this.dataGridRegister.Location = new System.Drawing.Point(6, 115);
            this.dataGridRegister.Name = "dataGridRegister";
            this.dataGridRegister.Size = new System.Drawing.Size(1140, 517);
            this.dataGridRegister.TabIndex = 21;
            this.dataGridRegister.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridRegister_CellContentClick);
            // 
            // projeVeriDataSet6
            // 
            this.projeVeriDataSet6.DataSetName = "ProjeVeriDataSet6";
            this.projeVeriDataSet6.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // propsMammalAnimalBindingSource
            // 
            this.propsMammalAnimalBindingSource.DataMember = "Props_Mammal_Animal";
            this.propsMammalAnimalBindingSource.DataSource = this.projeVeriDataSet6;
            // 
            // props_Mammal_AnimalTableAdapter
            // 
            this.props_Mammal_AnimalTableAdapter.ClearBeforeFill = true;
            // 
            // earringidDataGridViewTextBoxColumn
            // 
            this.earringidDataGridViewTextBoxColumn.DataPropertyName = "earring_id";
            this.earringidDataGridViewTextBoxColumn.HeaderText = "earring_id";
            this.earringidDataGridViewTextBoxColumn.Name = "earringidDataGridViewTextBoxColumn";
            // 
            // animaltypeDataGridViewTextBoxColumn
            // 
            this.animaltypeDataGridViewTextBoxColumn.DataPropertyName = "animal_type";
            this.animaltypeDataGridViewTextBoxColumn.HeaderText = "animal_type";
            this.animaltypeDataGridViewTextBoxColumn.Name = "animaltypeDataGridViewTextBoxColumn";
            this.animaltypeDataGridViewTextBoxColumn.Width = 150;
            // 
            // barnidDataGridViewTextBoxColumn
            // 
            this.barnidDataGridViewTextBoxColumn.DataPropertyName = "barn_id";
            this.barnidDataGridViewTextBoxColumn.HeaderText = "barn_id";
            this.barnidDataGridViewTextBoxColumn.Name = "barnidDataGridViewTextBoxColumn";
            this.barnidDataGridViewTextBoxColumn.Width = 130;
            // 
            // birthDateDataGridViewTextBoxColumn
            // 
            this.birthDateDataGridViewTextBoxColumn.DataPropertyName = "birthDate";
            this.birthDateDataGridViewTextBoxColumn.HeaderText = "birthDate";
            this.birthDateDataGridViewTextBoxColumn.Name = "birthDateDataGridViewTextBoxColumn";
            this.birthDateDataGridViewTextBoxColumn.Width = 150;
            // 
            // genderDataGridViewTextBoxColumn
            // 
            this.genderDataGridViewTextBoxColumn.DataPropertyName = "gender";
            this.genderDataGridViewTextBoxColumn.HeaderText = "gender";
            this.genderDataGridViewTextBoxColumn.Name = "genderDataGridViewTextBoxColumn";
            this.genderDataGridViewTextBoxColumn.Width = 150;
            // 
            // breedDataGridViewTextBoxColumn
            // 
            this.breedDataGridViewTextBoxColumn.DataPropertyName = "breed";
            this.breedDataGridViewTextBoxColumn.HeaderText = "breed";
            this.breedDataGridViewTextBoxColumn.Name = "breedDataGridViewTextBoxColumn";
            this.breedDataGridViewTextBoxColumn.Width = 150;
            // 
            // weightDataGridViewTextBoxColumn
            // 
            this.weightDataGridViewTextBoxColumn.DataPropertyName = "weight";
            this.weightDataGridViewTextBoxColumn.HeaderText = "weight";
            this.weightDataGridViewTextBoxColumn.Name = "weightDataGridViewTextBoxColumn";
            this.weightDataGridViewTextBoxColumn.Width = 130;
            // 
            // priceDataGridViewTextBoxColumn
            // 
            this.priceDataGridViewTextBoxColumn.DataPropertyName = "price";
            this.priceDataGridViewTextBoxColumn.HeaderText = "price";
            this.priceDataGridViewTextBoxColumn.Name = "priceDataGridViewTextBoxColumn";
            this.priceDataGridViewTextBoxColumn.Width = 150;
            // 
            // UC_Register
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.dataGridRegister);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "UC_Register";
            this.Size = new System.Drawing.Size(1146, 635);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridRegister)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.projeVeriDataSet6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.propsMammalAnimalBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnPoultryRegister;
        private System.Windows.Forms.Button btnRegisterAnimal;
        private System.Windows.Forms.DataGridView dataGridRegister;
        private System.Windows.Forms.Button btnBarn;
        private System.Windows.Forms.Button btnCoop;
        private System.Windows.Forms.DataGridViewTextBoxColumn earringidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn animaltypeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn barnidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn birthDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn genderDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn breedDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn weightDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource propsMammalAnimalBindingSource;
        private ProjeVeriDataSet6 projeVeriDataSet6;
        private ProjeVeriDataSet6TableAdapters.Props_Mammal_AnimalTableAdapter props_Mammal_AnimalTableAdapter;
    }
}
