﻿
namespace Farm_Automation.UserControls
{
    partial class UC_ProductReview
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_ProductReview));
            this.dataGridProductSpec = new System.Windows.Forms.DataGridView();
            this.proidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wareidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pronameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.waterDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.caloriesDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.totalfatDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cholestorelDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.carbohydrateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.proteinDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vitaminADataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.amountDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productionDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.expirationDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.propProductBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.projeVeriDataSet8 = new Farm_Automation.ProjeVeriDataSet8();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnProductRegister = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnExportXml = new System.Windows.Forms.Button();
            this.btnImportXLS = new System.Windows.Forms.Button();
            this.propProductTableAdapter = new Farm_Automation.ProjeVeriDataSet8TableAdapters.PropProductTableAdapter();
            this.vtnVaccine = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridProductSpec)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.propProductBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.projeVeriDataSet8)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridProductSpec
            // 
            this.dataGridProductSpec.AutoGenerateColumns = false;
            this.dataGridProductSpec.BackgroundColor = System.Drawing.Color.LightSeaGreen;
            this.dataGridProductSpec.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridProductSpec.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.proidDataGridViewTextBoxColumn,
            this.wareidDataGridViewTextBoxColumn,
            this.pronameDataGridViewTextBoxColumn,
            this.waterDataGridViewTextBoxColumn,
            this.caloriesDataGridViewTextBoxColumn,
            this.totalfatDataGridViewTextBoxColumn,
            this.cholestorelDataGridViewTextBoxColumn,
            this.carbohydrateDataGridViewTextBoxColumn,
            this.proteinDataGridViewTextBoxColumn,
            this.vitaminADataGridViewTextBoxColumn,
            this.amountDataGridViewTextBoxColumn,
            this.productionDateDataGridViewTextBoxColumn,
            this.expirationDateDataGridViewTextBoxColumn,
            this.priceDataGridViewTextBoxColumn});
            this.dataGridProductSpec.DataSource = this.propProductBindingSource;
            this.dataGridProductSpec.Location = new System.Drawing.Point(3, 104);
            this.dataGridProductSpec.Name = "dataGridProductSpec";
            this.dataGridProductSpec.Size = new System.Drawing.Size(1140, 401);
            this.dataGridProductSpec.TabIndex = 2;
            this.dataGridProductSpec.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridProductSpec_CellContentClick);
            // 
            // proidDataGridViewTextBoxColumn
            // 
            this.proidDataGridViewTextBoxColumn.DataPropertyName = "pro_id";
            this.proidDataGridViewTextBoxColumn.HeaderText = "pro_id";
            this.proidDataGridViewTextBoxColumn.Name = "proidDataGridViewTextBoxColumn";
            // 
            // wareidDataGridViewTextBoxColumn
            // 
            this.wareidDataGridViewTextBoxColumn.DataPropertyName = "ware_id";
            this.wareidDataGridViewTextBoxColumn.HeaderText = "ware_id";
            this.wareidDataGridViewTextBoxColumn.Name = "wareidDataGridViewTextBoxColumn";
            // 
            // pronameDataGridViewTextBoxColumn
            // 
            this.pronameDataGridViewTextBoxColumn.DataPropertyName = "pro_name";
            this.pronameDataGridViewTextBoxColumn.HeaderText = "pro_name";
            this.pronameDataGridViewTextBoxColumn.Name = "pronameDataGridViewTextBoxColumn";
            // 
            // waterDataGridViewTextBoxColumn
            // 
            this.waterDataGridViewTextBoxColumn.DataPropertyName = "water";
            this.waterDataGridViewTextBoxColumn.HeaderText = "water";
            this.waterDataGridViewTextBoxColumn.Name = "waterDataGridViewTextBoxColumn";
            // 
            // caloriesDataGridViewTextBoxColumn
            // 
            this.caloriesDataGridViewTextBoxColumn.DataPropertyName = "calories";
            this.caloriesDataGridViewTextBoxColumn.HeaderText = "calories";
            this.caloriesDataGridViewTextBoxColumn.Name = "caloriesDataGridViewTextBoxColumn";
            // 
            // totalfatDataGridViewTextBoxColumn
            // 
            this.totalfatDataGridViewTextBoxColumn.DataPropertyName = "total_fat";
            this.totalfatDataGridViewTextBoxColumn.HeaderText = "total_fat";
            this.totalfatDataGridViewTextBoxColumn.Name = "totalfatDataGridViewTextBoxColumn";
            // 
            // cholestorelDataGridViewTextBoxColumn
            // 
            this.cholestorelDataGridViewTextBoxColumn.DataPropertyName = "cholestorel";
            this.cholestorelDataGridViewTextBoxColumn.HeaderText = "cholestorel";
            this.cholestorelDataGridViewTextBoxColumn.Name = "cholestorelDataGridViewTextBoxColumn";
            // 
            // carbohydrateDataGridViewTextBoxColumn
            // 
            this.carbohydrateDataGridViewTextBoxColumn.DataPropertyName = "carbohydrate";
            this.carbohydrateDataGridViewTextBoxColumn.HeaderText = "carbohydrate";
            this.carbohydrateDataGridViewTextBoxColumn.Name = "carbohydrateDataGridViewTextBoxColumn";
            // 
            // proteinDataGridViewTextBoxColumn
            // 
            this.proteinDataGridViewTextBoxColumn.DataPropertyName = "protein";
            this.proteinDataGridViewTextBoxColumn.HeaderText = "protein";
            this.proteinDataGridViewTextBoxColumn.Name = "proteinDataGridViewTextBoxColumn";
            // 
            // vitaminADataGridViewTextBoxColumn
            // 
            this.vitaminADataGridViewTextBoxColumn.DataPropertyName = "vitamin_A";
            this.vitaminADataGridViewTextBoxColumn.HeaderText = "vitamin_A";
            this.vitaminADataGridViewTextBoxColumn.Name = "vitaminADataGridViewTextBoxColumn";
            // 
            // amountDataGridViewTextBoxColumn
            // 
            this.amountDataGridViewTextBoxColumn.DataPropertyName = "amount";
            this.amountDataGridViewTextBoxColumn.HeaderText = "amount";
            this.amountDataGridViewTextBoxColumn.Name = "amountDataGridViewTextBoxColumn";
            // 
            // productionDateDataGridViewTextBoxColumn
            // 
            this.productionDateDataGridViewTextBoxColumn.DataPropertyName = "productionDate";
            this.productionDateDataGridViewTextBoxColumn.HeaderText = "productionDate";
            this.productionDateDataGridViewTextBoxColumn.Name = "productionDateDataGridViewTextBoxColumn";
            // 
            // expirationDateDataGridViewTextBoxColumn
            // 
            this.expirationDateDataGridViewTextBoxColumn.DataPropertyName = "ExpirationDate";
            this.expirationDateDataGridViewTextBoxColumn.HeaderText = "ExpirationDate";
            this.expirationDateDataGridViewTextBoxColumn.Name = "expirationDateDataGridViewTextBoxColumn";
            // 
            // priceDataGridViewTextBoxColumn
            // 
            this.priceDataGridViewTextBoxColumn.DataPropertyName = "price";
            this.priceDataGridViewTextBoxColumn.HeaderText = "price";
            this.priceDataGridViewTextBoxColumn.Name = "priceDataGridViewTextBoxColumn";
            // 
            // propProductBindingSource
            // 
            this.propProductBindingSource.DataMember = "PropProduct";
            this.propProductBindingSource.DataSource = this.projeVeriDataSet8;
            // 
            // projeVeriDataSet8
            // 
            this.projeVeriDataSet8.DataSetName = "ProjeVeriDataSet8";
            this.projeVeriDataSet8.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.vtnVaccine);
            this.panel1.Controls.Add(this.btnProductRegister);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1146, 98);
            this.panel1.TabIndex = 3;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // btnProductRegister
            // 
            this.btnProductRegister.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnProductRegister.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProductRegister.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnProductRegister.Location = new System.Drawing.Point(1025, 3);
            this.btnProductRegister.Name = "btnProductRegister";
            this.btnProductRegister.Size = new System.Drawing.Size(118, 92);
            this.btnProductRegister.TabIndex = 2;
            this.btnProductRegister.Text = "Product Register";
            this.btnProductRegister.UseVisualStyleBackColor = false;
            this.btnProductRegister.Click += new System.EventHandler(this.btnProductRegister_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(505, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(189, 28);
            this.label1.TabIndex = 1;
            this.label1.Text = "Product Review";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(3, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(96, 93);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // btnExportXml
            // 
            this.btnExportXml.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnExportXml.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExportXml.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnExportXml.Location = new System.Drawing.Point(535, 520);
            this.btnExportXml.Name = "btnExportXml";
            this.btnExportXml.Size = new System.Drawing.Size(140, 71);
            this.btnExportXml.TabIndex = 4;
            this.btnExportXml.Text = "Export XLS";
            this.btnExportXml.UseVisualStyleBackColor = false;
            this.btnExportXml.Click += new System.EventHandler(this.btnExportXml_Click);
            // 
            // btnImportXLS
            // 
            this.btnImportXLS.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnImportXLS.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnImportXLS.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnImportXLS.Location = new System.Drawing.Point(389, 520);
            this.btnImportXLS.Name = "btnImportXLS";
            this.btnImportXLS.Size = new System.Drawing.Size(140, 71);
            this.btnImportXLS.TabIndex = 5;
            this.btnImportXLS.Text = "Import XLS";
            this.btnImportXLS.UseVisualStyleBackColor = false;
            // 
            // propProductTableAdapter
            // 
            this.propProductTableAdapter.ClearBeforeFill = true;
            // 
            // vtnVaccine
            // 
            this.vtnVaccine.BackColor = System.Drawing.Color.RoyalBlue;
            this.vtnVaccine.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vtnVaccine.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.vtnVaccine.Location = new System.Drawing.Point(105, 4);
            this.vtnVaccine.Name = "vtnVaccine";
            this.vtnVaccine.Size = new System.Drawing.Size(118, 92);
            this.vtnVaccine.TabIndex = 3;
            this.vtnVaccine.Text = "Vaccine Register";
            this.vtnVaccine.UseVisualStyleBackColor = false;
            this.vtnVaccine.Click += new System.EventHandler(this.vtnVaccine_Click);
            // 
            // UC_ProductReview
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Controls.Add(this.btnImportXLS);
            this.Controls.Add(this.btnExportXml);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.dataGridProductSpec);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "UC_ProductReview";
            this.Size = new System.Drawing.Size(1146, 635);
            this.Load += new System.EventHandler(this.UC_ProductReview_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridProductSpec)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.propProductBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.projeVeriDataSet8)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.DataGridView dataGridProductSpec;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnProductRegister;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnExportXml;
        private System.Windows.Forms.Button btnImportXLS;
        private System.Windows.Forms.DataGridViewTextBoxColumn proidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn wareidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pronameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn waterDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn caloriesDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn totalfatDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cholestorelDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn carbohydrateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn proteinDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn vitaminADataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn amountDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn productionDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn expirationDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource propProductBindingSource;
        private ProjeVeriDataSet8 projeVeriDataSet8;
        private ProjeVeriDataSet8TableAdapters.PropProductTableAdapter propProductTableAdapter;
        private System.Windows.Forms.Button vtnVaccine;
    }
}
