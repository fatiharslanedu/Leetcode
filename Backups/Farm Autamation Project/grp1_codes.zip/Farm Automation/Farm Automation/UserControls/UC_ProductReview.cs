﻿using Farm_Automation.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Farm_Automation.UserControls
{
    public partial class UC_ProductReview : UserControl
    {
        DataTable table = new DataTable("dataGridProductSpec");
        public UC_ProductReview()
        {
            InitializeComponent();
        }
        private SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-6K2RTP8;Initial Catalog=ProjeVeri;Integrated Security=True");
        public int id;
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void UC_ProductReview_Load(object sender, EventArgs e)
        {
            getProductRecord();
        }

        private void getProductRecord()
        {
            SqlCommand cmd = new SqlCommand("Select * from PropProduct", con);
            DataTable dt = new DataTable();

            con.Open();

            SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();

            dataGridProductSpec.DataSource = dt;
        }

        private void btnExportXml_Click(object sender, EventArgs e)


        {
            dataGridProductSpec.AllowUserToAddRows = false;
            if (dataGridProductSpec.Rows.Count > 0)
            {
                Microsoft.Office.Interop.Excel.Application xcelApp = new Microsoft.Office.Interop.Excel.Application();
                xcelApp.Application.Workbooks.Add(Type.Missing);
                for (int i = 1; i < dataGridProductSpec.Columns.Count+1; i++)
                {
                    xcelApp.Cells[1, i] = dataGridProductSpec.Columns[i - 1].HeaderText;
                }
                for (int i = 0; i < dataGridProductSpec.Rows.Count; i++)
                {
                    for (int j = 0; j < dataGridProductSpec.Columns.Count; j++)
                    {
                        xcelApp.Cells[i + 2, j + 1] = dataGridProductSpec.Rows[i].Cells[j].Value.ToString();
                    }
                }
                xcelApp.Columns.AutoFit();
                xcelApp.Visible = true;
            }

        }

        private void dataGridProductSpec_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnProductRegister_Click(object sender, EventArgs e)
        {
            using (productRegister productRegister = new productRegister())
            {
                productRegister.ShowDialog();
            }
        }

        private void vtnVaccine_Click(object sender, EventArgs e)
        {
            using (addVaccine add = new addVaccine())
            {
                add.ShowDialog();
            }
        }
    }
}
