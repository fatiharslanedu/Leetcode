﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Farm_Automation.UserControls
{
    public partial class UC_DataAnalys : UserControl
    {
        public System.Windows.Forms.DataGridViewAutoSizeColumnsMode AutoSizeColumnsMode { get; set; }
        public UC_DataAnalys()
        {
            InitializeComponent();
            dataGridView1.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.Fill);
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        
            dataGridView1.AllowUserToOrderColumns = true;
            dataGridView1.AllowUserToResizeColumns = true;
        }
        private SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-6K2RTP8;Initial Catalog=ProjeVeri;Integrated Security=True");
        public int id;
        private void btnQuery_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("Select personnel_name, personnel_surname, barn_name  From Staff_Members s Inner Join Barn b on s.personnel_id = b.personnel_id", con);
            DataTable dt = new DataTable();

            con.Open();

            SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();

            dataGridView1.DataSource = dt;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("Exec vaccineCheck", con);
            DataTable dt = new DataTable();

            con.Open();

            SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();

            dataGridView1.DataSource = dt;
        }

        private void btnPhone_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("SELECT b.barn_id, sm.tel_no FROM  Staff_Members sm INNER JOIN Barn b ON  sm.personnel_id = b.personnel_id where barn_id = 1", con);
            DataTable dt = new DataTable();

            con.Open();

            SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();

            dataGridView1.DataSource = dt;
        }

        private void UC_DataAnalys_Load(object sender, EventArgs e)
        {

        }

        private void btnExportJson_Click(object sender, EventArgs e)
        {
            var filename = @"C:\Users\build\source\repos\Farm Automation\Farm Automation\sample.json";

        }
        public void getRecord()
        {
            
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            

        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("EXEC Mammal_Breed @breed = @breed2;", con);
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("@breed2", comboBox1.Text);
            DataTable dt = new DataTable();

            con.Open();

            SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();
            dataGridView1.DataSource = dt;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("EXEC Total_Price_in_Selected_Poultry_Type 3", con);
            DataTable dt = new DataTable();

            con.Open();

            SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();

            dataGridView1.DataSource = dt;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("SELECT SUM(s.daily_milk_production) AS 'Total Daily Milk Production in Liters' FROM statusMammal s INNER JOIN props_mammal_Animal m ON m.earring_id = s.earring_id WHERE m.animal_type = 1", con);
            DataTable dt = new DataTable();

            con.Open();

            SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();

            dataGridView1.DataSource = dt;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("SELECT  SUM(s.daily_milk_production) AS 'Total Daily Milk Production in Liters' FROM statusMammal s INNER JOIN props_mammal_Animal m ON m.earring_id=s.earring_id WHERE m.animal_type=2 ", con);
            DataTable dt = new DataTable();

            con.Open();

            SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();

            dataGridView1.DataSource = dt;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("select top 30 p.earring_id, a.animal_name, b.barn_name,s.amountOf_meat, v.vaccine_name  from Props_Mammal_Animal p inner join Animals a on a.animal_type = p.animal_type inner join Barn b on p.barn_id =  b.barn_id inner join StatusMammal s on p.earring_id = s.earring_id inner join Vaccine v on s.vaccine_id = v.vaccine_id", con);
            DataTable dt = new DataTable();

            con.Open();

            SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();

            dataGridView1.DataSource = dt;
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("EXEC Total_Price_in_Selected_Mammal_Type @animal_name = @animal_name2;", con);
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("@animal_name2", comboBox2.Text);
            DataTable dt = new DataTable();

            con.Open();

            SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();
            dataGridView1.DataSource = dt;
        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("SELECT COUNT(earring_id) AS 'Total Cow Numbers' FROM props_mammal_Animal WHERE animal_type = 1", con);
            DataTable dt = new DataTable();

            con.Open();

            SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();

            dataGridView1.DataSource = dt;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("SELECT COUNT(earring_id) AS 'Total Sheep Numbers' FROM props_mammal_Animal WHERE animal_type = 2", con);
            DataTable dt = new DataTable();

            con.Open();

            SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();

            dataGridView1.DataSource = dt;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("SELECT COUNT(coop_id) 'Total Chicken Numbers' FROM props_poultry WHERE animal_type = 3", con);
            DataTable dt = new DataTable();

            con.Open();

            SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();

            dataGridView1.DataSource = dt;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("SELECT COUNT(earring_id) 'Total Goat Numbers' FROM props_mammal_Animal WHERE animal_type = 4", con);
            DataTable dt = new DataTable();

            con.Open();

            SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();

            dataGridView1.DataSource = dt;
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("EXEC Mammal_Breed @breed = @breed2;", con);
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("@breed2", comboBox1.Text);
            DataTable dt = new DataTable();

            con.Open();

            SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();
            dataGridView1.DataSource = dt;
        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("EXEC Total_Price_in_Selected_Poultry_Type 3", con);
            DataTable dt = new DataTable();

            con.Open();

            SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();

            dataGridView1.DataSource = dt;
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("SELECT SUM(s.daily_milk_production) AS 'Total Daily Milk Production in Liters' FROM statusMammal s INNER JOIN props_mammal_Animal m ON m.earring_id = s.earring_id WHERE m.animal_type = 1", con);
            DataTable dt = new DataTable();

            con.Open();

            SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();

            dataGridView1.DataSource = dt;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("Select * from Vaccine_Audit", con);
            DataTable dt = new DataTable();

            con.Open();

            SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();

            dataGridView1.DataSource = dt;
        }

        private void button12_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("Select * from StatusMammalTrigger", con);
            DataTable dt = new DataTable();

            con.Open();

            SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();

            dataGridView1.DataSource = dt;
        }
    }
}
