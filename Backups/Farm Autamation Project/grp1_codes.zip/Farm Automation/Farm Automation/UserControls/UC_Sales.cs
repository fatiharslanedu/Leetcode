﻿using DGVPrinterHelper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Farm_Automation.UserControls
{
    public partial class UC_Sales : UserControl
    {
        public UC_Sales()
        {
            InitializeComponent();
        }
        private SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-6K2RTP8;Initial Catalog=ProjeVeri;Integrated Security=True");
        public int id;
        private void UC_Sales_Load(object sender, EventArgs e)
        {
            getRecord();
            getlockedtxt();
        }
        private void getSellRecord()
        {
            SqlCommand cmd = new SqlCommand("Select * from tempSells", con);
            DataTable dt = new DataTable();

            con.Open();

            SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();

            userRecordDataGrid.DataSource = dt;
        }
        private void getRecord()
        {
            cmbproName.Items.Clear();
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from PropProduct";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                cmbproName.Items.Add(dr["pro_name"].ToString());
            }
            con.Close();
        }
        private void getlockedtxt()
        {
            txtExpiratDate.ReadOnly = true;
            txtPrice.ReadOnly = true;
            txtProdDate.ReadOnly = true;
            txtProID.ReadOnly = true;
           
        }
        private void cmbproName_SelectedIndexChanged(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from PropProduct where pro_name= '" + cmbproName.SelectedItem.ToString() + "'";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                txtProID.Text = dr["pro_id"].ToString();    
                txtProdDate.Text = dr["productionDate"].ToString();
                txtExpiratDate.Text = dr["ExpirationDate"].ToString();
                txtPrice.Text = dr["price"].ToString();
            }
            con.Close();
        }
        private bool isValid1()
        {
            if (txtProID.Text == string.Empty)
            {
                MessageBox.Show("Please Fiil all parts.", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        private void step2()
        {
            try
            {
                if (isValid1())
                {
                    SqlCommand cmd1 = new SqlCommand("INSERT INTO tempSells VALUES(@pro_id, @product_name, @amount, @production_date, @expiration_date, @price )", con);
                    cmd1.CommandType = CommandType.Text;
                    int ProID = int.Parse(txtProID.Text);
                    cmd1.Parameters.AddWithValue("@pro_id", ProID);
                    cmd1.Parameters.AddWithValue("@product_name", cmbproName.Text);
                    int amount = int.Parse(txtAmount.Text);
                    cmd1.Parameters.AddWithValue("@amount", amount);
                    cmd1.Parameters.AddWithValue("@production_date", txtProdDate.Text);
                    cmd1.Parameters.AddWithValue("@expiration_date", txtExpiratDate.Text);
                    decimal price = decimal.Parse(txtPrice.Text) * amount;
                    cmd1.Parameters.AddWithValue("@price", price);
                con.Open();
                    cmd1.ExecuteNonQuery();
                    con.Close();
                }
                else
                {
                    //MessageBox.Show("Please Select one of Them", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Incorrect enter");
            }
        }
        private void refresh()
        {
            txtAmount.Clear();
            txtExpiratDate.Clear();
            txtPrice.Clear();
            txtProdDate.Clear();
            txtProID.Clear();
          
        }
        private void btnAddtoCard_Click(object sender, EventArgs e)
        {
            step2();
            getSellRecord();
            refresh();

        }
        private void truncate()
        {
            using (SqlConnection cnn = new SqlConnection(@"Data Source=DESKTOP-6K2RTP8;Initial Catalog=ProjeVeri;Integrated Security=True"))
            using (SqlCommand cmd = new SqlCommand("TRUNCATE TABLE tempSells", cnn))
            {
                cnn.Open();
                cmd.ExecuteNonQuery();
            }
        }
        public void gobtn()
        {
            try
            {
                userRecordDataGrid[4, userRecordDataGrid.Rows.Count - 1].Value = "total";
                userRecordDataGrid.Rows[userRecordDataGrid.Rows.Count - 1].Cells[5].Style.BackColor = Color.Green;
                userRecordDataGrid.Rows[userRecordDataGrid.Rows.Count - 1].Cells[5].Style.ForeColor = Color.Red;

                decimal tot = 0;
                for (int i = 0; i < userRecordDataGrid.RowCount - 1; i++)
                {
                    var value = userRecordDataGrid.Rows[i].Cells[5].Value;
                    if (value != DBNull.Value)
                    {
                        tot += Convert.ToDecimal(value);
                    }
                }
                if (tot == 0)
                {
                }
                userRecordDataGrid.Rows[userRecordDataGrid.Rows.Count - 1].Cells[5].Value = tot.ToString();
                lbltotal.Text = tot.ToString();
            }
            catch
            {

            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            gobtn();
            truncate();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DGVPrinter printer = new DGVPrinter();
            printer.Title = "Green Customer Report";
            printer.SubTitle = string.Format("Date: {0}", DateTime.Now);
            printer.SubTitleFormatFlags = StringFormatFlags.LineLimit | StringFormatFlags.NoClip;
            printer.PageNumbers = true;
            printer.PageNumberInHeader = false;
            printer.PorportionalColumns = true;
            printer.HeaderCellAlignment = StringAlignment.Near;
            printer.Footer = "Green Farm Automation";
            printer.FooterSpacing = 15;
            printer.PrintDataGridView(userRecordDataGrid);
            truncate();
        }

        private void userRecordDataGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                txtProID.Text = userRecordDataGrid.SelectedRows[0].Cells[0].Value.ToString();
                cmbproName.Text = userRecordDataGrid.SelectedRows[0].Cells[1].Value.ToString();
                txtAmount.Text = userRecordDataGrid.SelectedRows[0].Cells[2].Value.ToString();
                txtProdDate.Text = userRecordDataGrid.SelectedRows[0].Cells[3].Value.ToString();
                txtExpiratDate.Text = userRecordDataGrid.SelectedRows[0].Cells[4].Value.ToString();
                txtPrice.Text = userRecordDataGrid.SelectedRows[0].Cells[5].Value.ToString();
            }
            catch
            {

            }
            
        }
        private void getsellRecord()
        {
            SqlCommand cmd = new SqlCommand("Select * from tempSells", con);
            DataTable dt = new DataTable();

            con.Open();

            SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();

            userRecordDataGrid.DataSource = dt;
        }
        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("DELETE FROM tempSells WHERE pro_id = @pro_id", con);
                cmd.CommandType = CommandType.Text;

                cmd.Parameters.AddWithValue("@pro_id", txtProID.Text);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                getsellRecord();
                refresh();
            }
            catch
            {

            }
        }
    }
}
