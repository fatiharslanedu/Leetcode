﻿
INSERT INTO Animals
VALUES(5, 'Cow')

INSERT INTO Animals (animal_type, animal_name)
VALUES 
	(1, 'Cow'),(2,'Sheep'), (3,'Chicken'), (4,'Goat')
	
INSERT INTO propProduct(pro_id, ware_id, pro_name, water, calories, total_fat, cholestorel, carbohydrate, protein, vitamin_A)
Values
	(1,2, 'Chicken Egg', 0.000, 75.000, 5.010, 0.213, 0.600, 6.250, 0.317),
(2,1,	'Chicken Meat',	0.000,	234.000,	17.100,	0.075,	0.000,	18.800, 0.013),	
(3,3,	'Cow Meat', 0.000, 251.000, 19.200, 0.067, 0.000, 18.200, 0.000),
(4,1,	'Cow Milk',	87.500,	42.300,	3.500,	0.050,	5.000,	3.400,	0.700),
(5,1,	'Goat Milk',	86.400,	45.200,	3.800,	0.070,	4.900,	3.100,	0.900),
(6,2,	'Goose Egg',	0.000,	185.000,	13.300,	0.825,	0.500,	13.900,	0.418),
(7,2,	'Sheep Meat',	0.000,	222.000,	17.200,	70.000,	0.000,	17.200,	0.000)

/* Insertion Barn */
INSERT INTO Barn (barn_id, barn_name, personnel_id)
VALUES 
	(1, 'Asagi', 3),(2,'Yukari', 4), (3,'Sol', 1), (4,'Sag', 5),
	(5, 'Kose', 1),(6,'Kis', 1), (7,'Yaz', 1), (8,'Kim', 1)
/* Insertion Coop */
INSERT INTO Coop (coop_id, personnel_id, coop_name, capacity, egg_production, feed_consumption)
Values
	(1, 1, 'asagi', 15, 32, 12000),
	(2, 3, 'yukari', 25, 45, 13000),
	(3, 2, 'sag', 16, 50, 14000),
	(4, 1, 'on', 35, 60, 16000),
	(5, 1, 'sol',5, 10, 600)

/* Insertion Staff_Members */
INSERT INTO Staff_Members (
			personnel_id, personnel_name, personnel_surname, birthDate,
			speciality, email, tel_no, start_dateOf_employee,  salary
			)
VALUES 
	(3, 'Kim Joan','Jordan','1990-10-03', 'barn', 'jordan@gmail.com', '5135464844', '1998-10-03', 1000),
	(4, 'Lexa','Victim','1984-11-06', 'coop', 'Victim@gmail.com', '5231264844', '1998-10-03', 2000),
	(5, 'Hithere','Jonathan','1994-06-13', 'barn', 'Jonathan@gmail.com', '5135464844', '1998-10-03', 3000)


/* Insertion StatusMammal */

INSERT INTO StatusMammal (earring_id, daily_milk_production, feed_water_consept, amountOf_meat, vaccine_id, vaccine_status, last_vaccine_date, fertility_rate)
VALUES
	(26100001, 20, 6, 500, 1, 'Yapildi', '2020-10-8', 42),
	(26100002, 10, 7, 600, 2, 'Yapilmadi', '2020-11-6', 25),
	(26100003, 15, 10, 700, 4, 'Yapildi', '2019-12-7', 45),
	(26100004, 16, 5, 800, 3, 'Yapildi', '2019-12-9', 9),
	(26100005, 8, 8, 00, 1, 'Yapilmadi', '2020-3-5', 9),
	(26100006, 9, 9, 800, 5, 'Yapildi', '2020-12-4', 42),
	(26100007, 10, 10, 900, 9, 'Yapildi', '2018-5-12', 65),
	(26100008, 12, 11, 1000, 7, 'Yapilmadi', '2019-12-3', 3),
	(26100009, 13, 12, 600, 1, 'Yapildi', '2020-4-12', 15)

/* Insertion Vaccine */
INSERT INTO Vaccine(vaccine_id, vaccine_name)
Values
(1, 'Handle'), (2, 'BRUCELLA'), (3, 'BCD'), (4, 'BRD'), (5, 'CLOSTRIDIAL'),
(6, 'Newcastle'), (7, 'Gumboro'), (8, 'Newcastle + Bronşişt'), (9, 'BRD'), (10, 'Koriza + Çiçek')

/* Insertion Props_Mammal_Animal */
INSERT INTO Props_Mammal_Animal(earring_id, animal_type,barn_id,birthDate,gender,breed,weight,price)
VALUES
(26100001,1,1,'2018-05-15','female','Holstein',724,9700),
(26100002,1,2,'2018-04-19','female','Holstein',800,9700),
(26100003,1,1,'2018-05-15','female','Holstein',689,8000),
(26100004,1,4,'2018-05-15','female','Simental',827,10600),
(26100005,1,3,'2018-02-27','male','Holstein',1004,11400),
(26100006,1,1,'2018-05-15','female','Jersey',820,10500),
(26100007,1,2,'2018-05-15','female','Holstein',950,9700),
(26100008,1,1,'2018-05-15','female','Holstein',780,11350),
(26100009,1,1,'2018-05-15','female','Simental',1068,9700),
(26100010,1,2,'2019-02-14','female','Holstein',718,9250),
(26100011,1,3,'2019-03-10','female','Jersey',720,9150),
(26100012,1,4,'2019-03-12','female','Simental',648,9700),
(26100013,1,1,'2018-05-15','male','Jersey',1200,11000),
(26100015,1,2,'2018-05-15','female','Jersey',1068,9700),
(26100016,1,3,'2018-05-15','female','Holstein',1068,9700),
(26100017,1,1,'2018-04-24','female','Jersey',724,10550),
(26100018,1,4,'2018-04-25','female','Holstein',881,10700),
(26100019,1,1,'2018-09-13','female','Jersey',780,10300),
(26100020,1,1,'2018-09-15','male','Holstein',814,9850),
(26100021,1,3,'2018-09-15','female','Simental',610,9999),
(26100022,1,4,'2018-09-15','female','Holstein',1068,9700)

/* Insertion Warehouse */

Insert into Warehouse(ware_id, earring_id, coop_id, stock, daily_milk_production, amountOf_meat, egg_production)
Values
(1, 26100001, null, 10, 1042, 345, 0),
(2, null, 2, 12, 0, 85, 20),
(3, null, 3, 5, 0, 67, 25),
(4, 26100004, null, 6, 578, 245, 0),
(5, 26100005, null, 7, 622, 655, 0),
(6, null, 4, 10, 0, 26, 25),
(7, 26100006, null, 15, 132, 213, 0)

/* Sheep Adding  */
INSERT INTO Props_Mammal_Animal(earring_id, animal_type,barn_id,birthDate,gender,breed,weight,price)
VALUES
(26200001,2,5,'2019-06-06','female','Merinos',41,1200),
(26200002,2,5,'2019-02-08','female','Merinos',40,1100),
(26200003,2,5,'2019-06-11','male','Merinos',53,1200),
(26200004,2,5,'2019-05-05','female','Merinos',48,1250),
(26200005,2,6,'2019-06-30','male','Merinos',51,1300),
(26200006,2,6,'2019-07-18','female','Merinos',44,1100),
(26200007,2,6,'2019-05-09','female','Merinos',46,1300),
(26200008,2,6,'2018-06-08','female','Merinos',51,1500),
(26200009,2,6,'2020-03-30','female','Merinos',43,1300),
(26300001,4,6,'2019-04-10','female','Kilis',54,1500),
(26300002,4,6,'2019-05-25','male','Kilis',48,1400),
(26300003,4,6,'2019-05-13','female','Kilis',45,1300),
(26300004,4,6,'2020-04-30','female','Kilis',47,1250),
(26300005,4,6,'2020-05-11','male','Kilis',44,1300),
(26300006,4,6,'2020-03-30','female','Kilis',45,1300),
(26300007,4,6,'2020-02-17','female','Kilis',49,1300),
(26300008,4,6,'2020-02-09','male','Kilis',48,1250),
(26300009,4,6,'2020-01-31','female','Kilis',48,1250)

Select * From animals


/* Props_poultry adding */
INSERT INTO Props_Poultry(bird_id,animal_type,coop_id,breed,price,weight,amountOf_meat)
VALUES
(1,3,1,'Ataks',45,2.13,1.5),
(2,3,1,'Ataks',35,2.12,1.5),
(3,3,1,'Sultan',30,2.32,1.8),
(4,3,1,'Sussex',30,2,1.2),
(5,3,1,'Ataks',35,2,1.6),
(6,3,1,'Ataks',35,2.32,1.5),
(7,3,1,'Sultan',38,2.32,1.4),
(8,3,1,'Ataks',35,2.11,1.2),
(9,3,1,'Sussex',46,3.23,1.5),
(10,3,1,'Ataks',65,3.14,1.9),
(11,3,1,'Sultan',40,4,3.5),
(12,3,1,'Ataks',55,2,1.25),
(13,3,1,'Ataks',55,3,1.5),
(14,3,1,'Sultan',60,4,1.53),
(15,3,1,'Ataks',36,5,1.59),
(16,3,2,'Sussex',30,2,1.8),
(17,3,2,'Ataks',35,3.2,1.425),
(18,3,2,'Sultan',30,2.4,1.52),
(19,3,2,'Ataks',35,2.1,1.45),
(20,3,2,'Ataks',25,2.3,1.58),
(21,3,2,'Sussex',40,2.3,1.7),
(22,3,2,'Sultan',24,2.4,1.6),
(23,3,2,'Ataks',35,2.1,1.17),
(24,3,2,'Ataks',35,2.123,1.48),
(25,3,2,'Sultan',26,2.3,1.55),
(26,3,2,'Ataks',35,3.1,1.56),
(27,3,2,'Ataks',45,3.4,1.23),
(28,3,2,'Sultan',37,2.5,1.9),
(29,3,2,'Sussex',48,3.7,1.68),
(30,3,2,'Sussex',45,3.2,1.75)



Go
Create Procedure vaccineCheck
As
SELECT 
pm.earring_id,
pm.breed,
st.vaccine_id,
st.vaccine_status
FROM StatusMammal st
INNER JOIN Vaccine v ON  v.vaccine_id=st.vaccine_id
INNER JOIN Props_Mammal_Animal pm ON st.earring_id=pm.earring_id
Go

Exec vaccineCheck
Drop Proc vaccineCheck